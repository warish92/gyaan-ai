# Copyright 2026 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

import asyncio
from collections.abc import Callable
import functools
import inspect
from typing import Any
from typing import get_type_hints
from typing import List
from typing import Optional
from typing import Union

from google.adk.agents.readonly_context import ReadonlyContext
from typing_extensions import override

from . import data_insights_tool
from . import metadata_tool
from . import query_tool
from . import search_tool
from ...tools.base_tool import BaseTool
from ...tools.base_toolset import BaseToolset
from ...tools.base_toolset import ToolPredicate
from ._bigquery_tool import BigQueryTool
from .bigquery_credentials import BigQueryCredentialsConfig
from .config import BigQueryToolConfig


@functools.lru_cache(maxsize=None)
def _wrap_async(func: Callable[..., Any]) -> Callable[..., Any]:
  """Wraps a sync tool function in an async adapter running it in a thread."""
  if inspect.iscoroutinefunction(func):
    return func

  @functools.wraps(func)
  async def async_adapter(*args: Any, **kwargs: Any) -> Any:
    return await asyncio.to_thread(func, *args, **kwargs)

  # Resolve string annotations in func's globals before FunctionType copies
  # drop __wrapped__.
  async_adapter.__annotations__ = get_type_hints(func)
  return async_adapter


class BigQueryToolset(BaseToolset):
  """Toolset with tools for interacting with BigQuery data and metadata.

  To equip your agent with curated instructions for BigQuery AI/ML functions
  (``"bigquery-ai-ml"``) or Graph Query Language (GQL) / SQL/PGQ queries
  (``"bigquery-graph"``) alongside these tools, pair ``BigQueryToolset`` with
  :func:`get_bigquery_skill` and ``SkillToolset``:

    from google.adk.integrations.bigquery import BigQueryToolset
    from google.adk.integrations.bigquery import get_bigquery_skill
    from google.adk.tools.skill_toolset import SkillToolset

    bigquery_toolset = BigQueryToolset(...)
    skill_toolset = SkillToolset(
        skills=[
            get_bigquery_skill("bigquery-ai-ml"),
            get_bigquery_skill("bigquery-graph"),
        ]
    )
    agent = LlmAgent(tools=[bigquery_toolset, skill_toolset])
  """

  def __init__(
      self,
      *,
      tool_filter: Optional[Union[ToolPredicate, List[str]]] = None,
      credentials_config: Optional[BigQueryCredentialsConfig] = None,
      bigquery_tool_config: Optional[BigQueryToolConfig] = None,
  ):
    super().__init__(tool_filter=tool_filter)
    self._credentials_config = credentials_config
    self._tool_settings = (
        bigquery_tool_config if bigquery_tool_config else BigQueryToolConfig()
    )

  def _is_tool_selected(
      self, tool: BaseTool, readonly_context: Optional[ReadonlyContext]
  ) -> bool:
    if self.tool_filter is None:
      return True

    if isinstance(self.tool_filter, ToolPredicate):
      return self.tool_filter(tool, readonly_context)

    if isinstance(self.tool_filter, list):
      return tool.name in self.tool_filter

    return False

  @override
  async def get_tools(
      self, readonly_context: Optional[ReadonlyContext] = None
  ) -> List[BaseTool]:
    """Get tools from the toolset."""
    funcs: list[Callable[..., Any]] = [
        metadata_tool.get_dataset_info,
        metadata_tool.get_table_info,
        metadata_tool.list_dataset_ids,
        metadata_tool.list_table_ids,
        metadata_tool.get_job_info,
        query_tool.get_execute_sql(self._tool_settings),
        query_tool.forecast,
        query_tool.analyze_contribution,
        query_tool.detect_anomalies,
        data_insights_tool.ask_data_insights,
        search_tool.search_catalog,
    ]
    all_tools = [
        BigQueryTool(
            func=_wrap_async(func),
            credentials_config=self._credentials_config,
            tool_settings=self._tool_settings,
        )
        for func in funcs
    ]

    return [
        tool
        for tool in all_tools
        if self._is_tool_selected(tool, readonly_context)
    ]

  @override
  async def close(self) -> None:
    pass
