# Copyright 2026 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

from contextlib import asynccontextmanager
import importlib
import json
import logging
import os
from pathlib import Path
import sys
from typing import Any
from typing import AsyncIterator
from typing import Awaitable
from typing import Callable
from typing import cast
from typing import Iterator
from typing import Literal
from typing import Mapping
from typing import TYPE_CHECKING

import click
from fastapi import FastAPI
from fastapi import HTTPException
from fastapi import Request
from fastapi.encoders import jsonable_encoder
from fastapi.responses import JSONResponse
from fastapi.responses import StreamingResponse
from google.genai import types
from opentelemetry import context
from opentelemetry import trace
from opentelemetry.sdk.trace import export
from opentelemetry.sdk.trace import TracerProvider
from pydantic import BaseModel
from starlette.concurrency import run_in_threadpool
from starlette.types import Lifespan

from ..auth.credential_service.in_memory_credential_service import InMemoryCredentialService
from ..runners import Runner
from ..telemetry._agent_engine import get_propagated_context
from ..telemetry._agent_engine import maybe_install_request_metrics_middleware
from ..telemetry._agent_engine import TopSpanProcessor
from .api_server import _is_loopback_address
from .api_server import ApiServer
from .cli_deploy import _AGENT_ENGINE_CLASS_METHODS
from .service_registry import load_services_module
from .utils import envs
from .utils.agent_change_handler import AgentChangeEventHandler
from .utils.agent_loader import is_single_agent_directory
from .utils.base_agent_loader import BaseAgentLoader
from .utils.service_factory import _create_task_store_from_options
from .utils.service_factory import create_artifact_service_from_options
from .utils.service_factory import create_memory_service_from_options
from .utils.service_factory import create_session_service_from_options

if TYPE_CHECKING:
  from collections.abc import Sequence

  # watchdog types Observer as a factory, so type checkers see its base class.
  from watchdog.observers.api import BaseObserver as Observer
else:
  from watchdog.observers import Observer

_ALLOWED_AGENT_ENGINE_CLASS_METHODS = frozenset(
    method["name"] for method in _AGENT_ENGINE_CLASS_METHODS
)


class _QueryRequest(BaseModel):
  input: dict[str, Any] | None = None
  class_method: str | None = None


logger = logging.getLogger("google_adk." + __name__)

_LAZY_SERVICE_IMPORTS: dict[str, str] = {
    "AgentLoader": ".utils.agent_loader",
    "NestedAgentLoader": ".utils._nested_agent_loader",
    "LocalEvalSetResultsManager": "..evaluation.local_eval_set_results_manager",
    "LocalEvalSetsManager": "..evaluation.local_eval_sets_manager",
}


def __getattr__(name: str) -> object:
  """Lazily import defaults so patching in tests keeps working."""
  if name not in _LAZY_SERVICE_IMPORTS:
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

  module = importlib.import_module(_LAZY_SERVICE_IMPORTS[name], __package__)
  attr = getattr(module, name)
  globals()[name] = attr
  return attr


def get_fast_api_app(
    *,
    agents_dir: str,
    agent_loader: BaseAgentLoader | None = None,
    session_service_uri: str | None = None,
    session_db_kwargs: Mapping[str, Any] | None = None,
    artifact_service_uri: str | None = None,
    memory_service_uri: str | None = None,
    use_local_storage: bool = True,
    eval_storage_uri: str | None = None,
    allow_origins: list[str] | None = None,
    web: bool,
    a2a: bool = False,
    task_store_uri: str | None = None,
    host: str = "127.0.0.1",
    bind_host: str | None = None,
    port: int = 8000,
    url_prefix: str | None = None,
    trace_to_cloud: bool = False,
    otel_to_cloud: bool = False,
    reload_agents: bool = False,
    lifespan: Lifespan[FastAPI] | None = None,
    extra_plugins: list[str] | None = None,
    logo_text: str | None = None,
    logo_image_url: str | None = None,
    auto_create_session: bool = False,
    trigger_sources: (
        list[Literal["pubsub", "eventarc"]] | Sequence[str] | None
    ) = None,
    trigger_oidc_audience: str | None = None,
    trigger_oidc_service_accounts: list[str] | None = None,
    trigger_auth_verifier: (
        Callable[[Request], None | Awaitable[None]] | None
    ) = None,
    default_llm_model: str | None = None,
    gemini_enterprise_app_name: str | None = None,
    express_mode: bool = False,
    avatar_config: types.AvatarConfig | None = None,
    max_llm_calls: int | None = None,
) -> FastAPI:
  """Constructs and returns a FastAPI application for serving ADK agents.

  This function orchestrates the initialization of core ADK services (Session,
  Artifact, Memory, and Credential) based on the provided configuration,
  configures the ADK Web Server, and optionally enables advanced features
  like Agent-to-Agent (A2A) protocol support and cloud telemetry.

  Args:
    agents_dir: The root directory containing agent definitions. This path is
      used to discover agents, load custom service registrations (via
      services.py/yaml), and as a base for local storage.
    agent_loader: An optional custom loader for retrieving agent instances. If
      not provided, a default AgentLoader targeting agents_dir is used.
    session_service_uri: A URI defining the backend for session persistence.
      Supports schemes like 'memory://', 'sqlite://', 'postgresql://',
      'mysql://', or 'agentengine://'. Defaults to per-agent local SQLite
      storage if None.
    session_db_kwargs: Optional keyword arguments for custom session service
      initialization. These are passed to the service factory along with the
      URI.
    artifact_service_uri: URI for the artifact service. Uses local artifact
      service if None.
    memory_service_uri: URI for the memory service. Uses local memory service if
      None.
    use_local_storage: Whether to use local storage for session and artifacts.
    eval_storage_uri: URI for evaluation storage. Supports ``gs://<bucket>``
      for GCS and ``file://<path>`` for a local directory. When omitted,
      ``ADK_EVAL_STORAGE_URI`` is used if set, and local eval files default to
      ``agents_dir``.
    allow_origins: List of allowed origins for CORS.
    web: Whether to enable the web UI and serve its assets.
    a2a: Whether to enable Agent-to-Agent (A2A) protocol support.
    task_store_uri: URI for the A2A task store. Uses in-memory task store if
      None. Only used when ``a2a=True``.
    host: Host address for the server (defaults to 127.0.0.1). Unused by the
      returned app; pass ``bind_host`` to guard it.
    bind_host: The address the caller will bind the returned app to. A loopback
      value turns on DNS-rebinding protection, which rejects requests addressed
      to any other host. A non-loopback value logs a startup warning that the
      app has no authentication. Leave it None to serve the app yourself
      without either. Internal agents, such as the agent builder assistant,
      are served only when this is a loopback address.
    port: Port number for the server (defaults to 8000).
    url_prefix: Optional prefix for all URL routes.
    trace_to_cloud: Whether to export traces to Google Cloud Trace.
    otel_to_cloud: Whether to export OpenTelemetry data to Google Cloud.
    reload_agents: Whether to watch for file changes and reload agents.
    lifespan: Optional FastAPI lifespan context manager.
    extra_plugins: List of extra plugin names to load.
    logo_text: Text to display in the web UI logo area.
    logo_image_url: URL for an image to display in the web UI logo area.
    auto_create_session: Whether to automatically create a session when not
      found.
    trigger_sources: List of trigger sources to enable (e.g. ["pubsub",
      "eventarc"]). When set, registers /trigger/* endpoints for batch and
      event-driven agent invocations. None disables all trigger endpoints.
    trigger_oidc_audience: When set, every /trigger/* request must carry a
      Google-signed OIDC bearer token whose audience matches this value.
    trigger_oidc_service_accounts: When set alongside ``trigger_oidc_audience``,
      every /trigger/* request's bearer token must be owned by one of these
      service account emails. This completes authentication of the caller. When
      None (the default), token signatures and audience are still verified if
      ``trigger_oidc_audience`` is set, but caller identity is not enforced.
    trigger_auth_verifier: A custom callable to verify incoming trigger
      requests. Takes a FastAPI ``Request`` and should raise ``HTTPException``
      on failure. When set, overrides ``trigger_oidc_audience``.
    default_llm_model: Default LLM model to use for the agent.
    gemini_enterprise_app_name: The Gemini Enterprise app name to use for the
      agent.
    express_mode: Whether to enable express mode.
    avatar_config: Avatar configuration to apply to live agent runs that
      request VIDEO output.
    max_llm_calls: Maximum number of LLM calls allowed for each agent run.
      When None, ``RunConfig`` resolves its normal default.

  Returns:
    The configured FastAPI application instance.
  """

  if bind_host is not None and not _is_loopback_address(bind_host):
    logger.warning(
        "ADK server is binding to a non-loopback address (%s) and has no"
        " authentication: any client that can reach it can read, modify, and"
        " delete any user's sessions and artifacts. Do not expose it to"
        " untrusted networks without an authenticating proxy.",
        bind_host,
    )

  # Enable the YAML key denylist for config loads if the web UI is enabled.
  if web:
    from ..agents import config_agent_utils

    config_agent_utils._set_enforce_yaml_key_denylist(True)

  # Detect single agent mode
  agents_path = Path(agents_dir).resolve()
  is_single_agent = is_single_agent_directory(agents_path)

  original_agents_dir = agents_dir
  single_agent_name = None
  if is_single_agent:
    single_agent_name = agents_path.name
    agents_dir = str(agents_path.parent)

  # Set up eval managers.
  from .utils import _eval_storage

  this_module = sys.modules[__name__]
  eval_sets_manager, eval_set_results_manager = (
      _eval_storage.create_eval_managers(
          eval_storage_uri,
          agents_dir,
          local_eval_sets_manager_cls=this_module.LocalEvalSetsManager,
          local_eval_set_results_manager_cls=(
              this_module.LocalEvalSetResultsManager
          ),
      )
  )

  # initialize Agent Loader if not passed as argument
  if agent_loader is None:
    if web:
      agent_loader = this_module.NestedAgentLoader(original_agents_dir)
    else:
      agent_loader = this_module.AgentLoader(original_agents_dir)
  else:
    if is_single_agent and isinstance(agent_loader, this_module.AgentLoader):
      if single_agent_name is not None:
        agent_loader._set_single_agent_mode(single_agent_name, agents_dir)
  # The built-in agents include the agent builder assistant, which writes
  # arbitrary files -- Python included -- that the server then imports. The
  # dev server has no authentication, so they are only safe where nobody else
  # can reach it: a loopback bind, which the DNS-rebinding and Origin guards
  # also cover. An unknown bind (None) is treated as exposed.
  allow_special_agents = (
      web and bind_host is not None and _is_loopback_address(bind_host)
  )
  agent_loader._allow_special_agents = allow_special_agents

  # services.py lives in the folder the user passed, not the rewritten parent.
  load_services_module(original_agents_dir)

  # Build the Memory service
  try:
    memory_service = create_memory_service_from_options(
        base_dir=agents_dir,
        memory_service_uri=memory_service_uri,
    )
  except ValueError as exc:
    raise click.ClickException(str(exc)) from exc

  # Build the Session service
  session_service = create_session_service_from_options(
      base_dir=agents_dir,
      session_service_uri=session_service_uri,
      session_db_kwargs=(
          dict(session_db_kwargs) if session_db_kwargs is not None else None
      ),
      use_local_storage=use_local_storage,
  )

  # Build the Artifact service
  try:
    artifact_service = create_artifact_service_from_options(
        base_dir=agents_dir,
        artifact_service_uri=artifact_service_uri,
        strict_uri=True,
        use_local_storage=use_local_storage,
    )
  except ValueError as exc:
    raise click.ClickException(str(exc)) from exc

  # Build  the Credential service
  credential_service = InMemoryCredentialService()

  # Instantiate the appropriate server class based on web option
  # If web=True, use DevServer (includes all endpoints: production + dev)
  # If web=False, use ApiServer (production-safe endpoints only)
  ServerClass: type[ApiServer]
  if web:
    try:
      from .dev_server import DevServer

      ServerClass = DevServer
    except ModuleNotFoundError as e:
      # Fallback to ApiServer if dev_server.py is not available
      # (e.g., in production packages where dev_server.py is excluded)
      if e.name and e.name.endswith("dev_server"):
        logger.warning(
            "DevServer not found, falling back to ApiServer. "
            "Debug and evaluation endpoints will not be available."
        )
        ServerClass = ApiServer
      else:
        raise
  else:
    ServerClass = ApiServer

  adk_web_server = ServerClass(
      agent_loader=agent_loader,
      session_service=session_service,
      artifact_service=artifact_service,
      memory_service=memory_service,
      credential_service=credential_service,
      eval_sets_manager=eval_sets_manager,
      eval_set_results_manager=eval_set_results_manager,
      agents_dir=agents_dir,
      extra_plugins=extra_plugins,
      logo_text=logo_text,
      logo_image_url=logo_image_url,
      url_prefix=url_prefix,
      auto_create_session=auto_create_session,
      trigger_sources=trigger_sources,
      trigger_oidc_audience=trigger_oidc_audience,
      trigger_oidc_service_accounts=trigger_oidc_service_accounts,
      trigger_auth_verifier=trigger_auth_verifier,
      default_llm_model=default_llm_model,
      avatar_config=avatar_config,
      max_llm_calls=max_llm_calls,
  )
  # DevServer allows the built-in agents by default. Follow the loader, so a
  # refused request gets the server's 403 rather than a 500 from the loader's
  # PermissionError. Only ever narrows: ApiServer stays closed even if web fell
  # back to it.
  adk_web_server._allow_special_agents = (
      adk_web_server._allow_special_agents and allow_special_agents
  )

  # In single agent mode, use that agent as the default app.
  if is_single_agent:
    adk_web_server.default_app_name = single_agent_name

  # Callbacks & other optional args for when constructing the FastAPI instance
  extra_fast_api_args: dict[str, Any] = {}

  # TODO - Remove separate trace_to_cloud logic once otel_to_cloud stops being
  # EXPERIMENTAL.
  if trace_to_cloud and not otel_to_cloud:
    from opentelemetry.exporter.cloud_trace import CloudTraceSpanExporter

    def register_processors(provider: TracerProvider) -> None:
      envs.load_dotenv_for_agent("", agents_dir)
      if project_id := os.environ.get("GOOGLE_CLOUD_PROJECT", None):
        processor = export.BatchSpanProcessor(
            CloudTraceSpanExporter(project_id=project_id)
        )
        provider.add_span_processor(processor)
      else:
        logger.warning(
            "GOOGLE_CLOUD_PROJECT environment variable is not set. Tracing will"
            " not be enabled."
        )

    extra_fast_api_args.update(
        register_processors=register_processors,
    )

  if reload_agents:

    def setup_observer(observer: Observer, adk_web_server: ApiServer) -> None:
      agent_change_handler = AgentChangeEventHandler(
          agent_loader=agent_loader,
          runners_to_clean=adk_web_server.runners_to_clean,
          agents_dir=agents_dir,
      )
      observer.schedule(agent_change_handler, agents_dir, recursive=True)
      observer.start()

    def tear_down_observer(observer: Observer, _: ApiServer) -> None:
      observer.stop()
      observer.join()

    extra_fast_api_args.update(
        setup_observer=setup_observer,
        tear_down_observer=tear_down_observer,
    )

  if web:
    BASE_DIR = Path(__file__).parent.resolve()
    ANGULAR_DIST_PATH = BASE_DIR / "browser"
    extra_fast_api_args.update(
        web_assets_dir=ANGULAR_DIST_PATH,
    )

  # Create the task store early so its engine can be disposed via the
  # lifespan, preventing connection pool leaks on shutdown.
  a2a_task_store = None
  if a2a:
    base_path = Path.cwd() / agents_dir
    if base_path.exists() and base_path.is_dir():
      a2a_task_store = _create_task_store_from_options(
          task_store_uri=task_store_uri,
      )

  if a2a_task_store is not None and hasattr(a2a_task_store, "engine"):
    outer_lifespan = lifespan

    @asynccontextmanager
    async def _a2a_lifespan(
        app_instance: FastAPI,
    ) -> AsyncIterator[Mapping[str, Any] | None]:
      try:
        if outer_lifespan:
          async with outer_lifespan(app_instance) as ctx:
            yield ctx
        else:
          yield None
      finally:
        logger.info("Disposing A2A task store engine")
        await a2a_task_store.engine.dispose()

    # Stateless exactly when outer_lifespan is, since it yields outer's state.
    lifespan = cast("Lifespan[FastAPI]", _a2a_lifespan)

  app = adk_web_server.get_fast_api_app(
      lifespan=lifespan,
      allow_origins=allow_origins,
      otel_to_cloud=otel_to_cloud,
      bind_host=bind_host,
      **extra_fast_api_args,
  )

  maybe_install_request_metrics_middleware(app, otel_to_cloud=otel_to_cloud)

  if a2a and a2a_task_store is not None:
    from a2a.server.tasks import InMemoryPushNotificationConfigStore

    from ..a2a import _compat
    from ..a2a.executor.a2a_agent_executor import A2aAgentExecutor

    # locate all a2a agent apps in the agents directory
    base_path = Path.cwd() / agents_dir
    # the root agents directory should be an existing folder
    if base_path.exists() and base_path.is_dir():

      def create_a2a_runner_loader(
          captured_app_name: str,
      ) -> Callable[[], Awaitable[Runner]]:
        """Factory function to create A2A runner with proper closure."""

        async def _get_a2a_runner_async() -> Runner:
          return await adk_web_server.get_runner_async(captured_app_name)

        return _get_a2a_runner_async

      for p in base_path.iterdir():
        # only folders with an agent.json file representing agent card are valid
        # a2a agents
        if (
            p.is_file()
            or p.name.startswith((".", "__pycache__"))
            or not (p / "agent.json").is_file()
        ):
          continue

        app_name = p.name
        logger.info("Setting up A2A agent: %s", app_name)

        try:
          agent_executor = A2aAgentExecutor(
              runner=create_a2a_runner_loader(app_name),
          )

          push_config_store = InMemoryPushNotificationConfigStore()

          with (p / "agent.json").open("r", encoding="utf-8") as f:
            data = json.load(f)
            agent_card = _compat.parse_agent_card(data)

          _compat.attach_a2a_routes_to_app(
              app,
              agent_card=agent_card,
              agent_executor=agent_executor,
              task_store=a2a_task_store,
              push_config_store=push_config_store,
              prefix=f"/a2a/{app_name}",
          )

          logger.info("Successfully configured A2A agent: %s", app_name)

        except Exception as e:
          logger.error("Failed to setup A2A agent %s: %s", app_name, e)
          # Continue with other agents even if one fails

  if gemini_enterprise_app_name:
    if gemini_enterprise_app_name not in agent_loader.list_agents():
      raise ValueError(
          f"App {gemini_enterprise_app_name} not found in dir: {agents_dir}"
      )

    import inspect

    from google.adk.agents import Agent
    import google.auth
    from pydantic import ValidationError as _ValidationError

    from ..dependencies._agentplatform_frameworks import frameworks

    # The tmp agent will be replaced by the adk server's runner and services.
    # It is specified here because it is a required argument to AdkApp.
    adk_app = frameworks.AdkApp(agent=Agent(name="tmp"))
    if express_mode:
      api_key = os.environ.get("GOOGLE_API_KEY", None)
      if not api_key:
        raise ValueError(
            "No GOOGLE_API_KEY found in environment variables for express mode."
        )
      # TODO: b/570766726 - Drop these pops once AdkApp.set_up() lets callers
      # select express mode without consulting os.environ.
      # Agent Platform v2 dropped the global initializer: AdkApp.set_up()
      # reads the project from the environment rather than from _tmpl_attrs,
      # and selects express mode only when it finds none. Clearing it is
      # therefore the only way to express what _tmpl_attrs["project"] = None
      # used to say. Scoping the removal to the AdkApp call is not an option:
      # set_up() runs lazily inside a request, so a per-request save/restore
      # would race between concurrent requests on a process-wide mapping.
      # GOOGLE_CLOUD_LOCATION is left to set_up(), which pops it itself on the
      # express path. Popping it here too would make no difference to what the
      # rest of the process sees, and set_up() reads it as a fallback for the
      # region before it gets there.
      os.environ.pop("GOOGLE_CLOUD_PROJECT", None)
      os.environ.pop("GOOGLE_CLOUD_AGENT_ENGINE_LOCATION", None)
      adk_app._tmpl_attrs["express_mode_api_key"] = api_key
    else:
      _, project_id = google.auth.default()
      location = os.environ.get(
          "GOOGLE_CLOUD_AGENT_ENGINE_LOCATION",
          os.environ.get("GOOGLE_CLOUD_LOCATION", None),
      )
      if not project_id or not location:
        raise ValueError(
            "No GOOGLE_CLOUD_PROJECT or GOOGLE_CLOUD_LOCATION found in"
            " environment variables."
        )
      # The ADC-resolved project has to win over a stale one, the way
      # _tmpl_attrs["project"] did before v2 removed the global initializer.
      # `location` may have come from GOOGLE_CLOUD_AGENT_ENGINE_LOCATION, which
      # set_up() prefers, so it is published under that name only. Writing it
      # to GOOGLE_CLOUD_LOCATION here would overwrite whatever region the rest
      # of the process had already agreed on. set_up() still copies it into
      # GOOGLE_CLOUD_LOCATION when that variable is unset, which is the case
      # this cannot and should not prevent; what it avoids is clobbering a
      # value that was already there.
      os.environ["GOOGLE_CLOUD_PROJECT"] = project_id
      os.environ["GOOGLE_CLOUD_AGENT_ENGINE_LOCATION"] = location
      adk_app._tmpl_attrs["express_mode_api_key"] = None
    adk_app._tmpl_attrs["runner"] = None
    adk_app._tmpl_attrs["app_name"] = gemini_enterprise_app_name
    adk_app._tmpl_attrs["session_service"] = session_service
    adk_app._tmpl_attrs["memory_service"] = memory_service
    adk_app._tmpl_attrs["artifact_service"] = artifact_service

    def _encode_chunk_to_json(chunk: Any) -> str | None:
      """Encodes a chunk to a JSON string with a newline."""
      try:
        json_chunk = jsonable_encoder(chunk)
        return f"{json.dumps(json_chunk)}\n"
      except Exception:
        logging.exception("Failed to encode chunk")
        return None

    async def json_generator(output: AsyncIterator[Any]) -> AsyncIterator[str]:
      async for chunk in output:
        encoded_chunk = _encode_chunk_to_json(chunk)
        if encoded_chunk is None:
          break
        yield encoded_chunk

    async def _invoke_callable_or_raise(
        invocation_callable: Callable[..., Any],
        invocation_payload: dict[str, Any],
    ) -> Any:
      if inspect.iscoroutinefunction(invocation_callable):
        return await invocation_callable(**invocation_payload)
      elif inspect.isasyncgenfunction(invocation_callable):
        return invocation_callable(**invocation_payload)
      else:
        return await run_in_threadpool(
            invocation_callable, **invocation_payload
        )

    # Implement a FastAPI middleware to extract and attach OpenTelemetry trace
    # context from a custom Google-Agent-Engine-Traceparent header in incoming
    # requests. This enables distributed tracing.
    tracer_provider = trace.get_tracer_provider()
    if isinstance(tracer_provider, TracerProvider):
      tracer_provider.add_span_processor(TopSpanProcessor())
    else:
      logging.warning(
          "OpenTelemetry tracing is not enabled. Please set the"
          " `OTEL_PYTHON_TRACER_PROVIDER` environment variable to enable"
          " tracing."
      )

    @app.post(
        "/api/reasoning_engine",
        response_model_exclude_none=True,
        response_class=JSONResponse,
    )
    async def query(request: Request) -> JSONResponse:
      try:
        body = await request.json()
      except json.JSONDecodeError as exc:
        raise HTTPException(status_code=400, detail=f"Invalid JSON: {exc}")
      try:
        parsed = _QueryRequest.model_validate(body)
      except _ValidationError as exc:
        raise HTTPException(status_code=400, detail=exc.errors())
      if not adk_app._tmpl_attrs.get("runner"):
        adk_app._tmpl_attrs["runner"] = await adk_web_server.get_runner_async(
            app_name=gemini_enterprise_app_name
        )
      if parsed.class_method is None:
        raise HTTPException(
            status_code=400, detail="class_method cannot be None"
        )
      if parsed.class_method not in _ALLOWED_AGENT_ENGINE_CLASS_METHODS:
        raise HTTPException(
            status_code=400,
            detail=f"class_method {parsed.class_method} is not allowed",
        )
      method = getattr(adk_app, parsed.class_method)
      output = await _invoke_callable_or_raise(method, parsed.input or {})

      try:
        json_serialized_content = jsonable_encoder({"output": output})
      except ValueError as encoding_error:
        logging.exception(
            "FastAPI could not JSON-encode the response from invocation method"
            " %s. Error: %s. Invocation method's original response: %r",
            parsed.class_method,
            encoding_error,
            output,
        )
        raise
      return JSONResponse(content=json_serialized_content)

    @app.post(
        "/api/stream_reasoning_engine",
        response_model_exclude_none=True,
        response_class=StreamingResponse,
    )
    async def stream_query(request: Request) -> StreamingResponse:
      try:
        body = await request.json()
      except json.JSONDecodeError as exc:
        raise HTTPException(status_code=400, detail=f"Invalid JSON: {exc}")
      try:
        parsed = _QueryRequest.model_validate(body)
      except _ValidationError as exc:
        raise HTTPException(status_code=400, detail=exc.errors())
      if not adk_app._tmpl_attrs.get("runner"):
        adk_app._tmpl_attrs["runner"] = await adk_web_server.get_runner_async(
            app_name=gemini_enterprise_app_name
        )
      if parsed.class_method is None:
        raise HTTPException(
            status_code=400, detail="class_method cannot be None"
        )
      if parsed.class_method not in _ALLOWED_AGENT_ENGINE_CLASS_METHODS:
        raise HTTPException(
            status_code=400,
            detail=f"class_method {parsed.class_method} is not allowed",
        )
      method = getattr(adk_app, parsed.class_method)
      output = await _invoke_callable_or_raise(method, parsed.input or {})

      if inspect.isgenerator(output):
        # Sentinel-based exhaustion check. We cannot rely on catching
        # StopIteration here: when ``next(iterator)`` is called inside the
        # threadpool worker, the StopIteration propagates out of the
        # ``run_in_threadpool`` coroutine frame, and Python (PEP 479) converts
        # it to ``RuntimeError("coroutine raised StopIteration")`` before the
        # ``except StopIteration`` clause can ever see it. Passing a default to
        # ``next`` avoids raising at the boundary entirely.
        _SENTINEL = object()

        async def _aiter_from_iter(
            iterator: Iterator[object],
        ) -> AsyncIterator[object]:
          while True:
            chunk = await run_in_threadpool(next, iterator, _SENTINEL)
            if chunk is _SENTINEL:
              break
            yield chunk

        content_iter = _aiter_from_iter(output)
      else:
        content_iter = output

      return StreamingResponse(
          content=json_generator(content_iter),
          media_type="application/json",
      )

  @app.middleware("http")
  async def context_propagation(
      request: Request, call_next: Callable[[Request], Awaitable[Any]]
  ) -> Any:
    ctx = get_propagated_context(request)
    token = context.attach(ctx)
    try:
      response = await call_next(request)
      return response
    finally:
      context.detach(token)

  return app
