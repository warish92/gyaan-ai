# Copyright 2026 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

import asyncio
from contextlib import aclosing
import json
import logging
import math
from typing import AsyncGenerator

from google.genai import types
from opentelemetry.semconv.attributes.error_attributes import ERROR_TYPE
from opentelemetry.trace import Status
from opentelemetry.trace import StatusCode

from ..events._rewind_events import _apply_rewinds
from ..events.event import Event
from ..events.event_actions import EventActions
from ..events.event_actions import EventCompaction
from ..sessions.base_session_service import BaseSessionService
from ..sessions.session import Session
from ..telemetry import _instrumentation
from ..telemetry.tracing import _build_compaction_attributes
from ..telemetry.tracing import _build_compaction_result_attributes
from ..telemetry.tracing import resolve_error_type
from ..telemetry.tracing import tracer
from ..utils._function_call_names import CLIENT_FUNCTION_CALL_NAMES as _CLIENT_FUNCTION_CALL_NAMES
from ..workflow import BaseNode
from .app import App
from .app import EventsCompactionConfig
from .llm_event_summarizer import LlmEventSummarizer

logger = logging.getLogger('google_adk.' + __name__)


def _request_content(event: Event) -> types.Content | None:
  """The content this event contributes to a request, if any.

  A compaction event carries its summary in
  `actions.compaction.compacted_content`, not in `content`: the shipped
  summarizer leaves `content` unset, and prompt assembly materializes a fresh
  event from the compacted content instead. Sizing `content` alone therefore
  measures every real summary as zero characters.

  Args:
    event: The event to read.

  Returns:
    The compacted content for a compaction event, otherwise `event.content`.
  """
  compaction = event.actions.compaction if event.actions else None
  if compaction is not None and compaction.compacted_content is not None:
    return compaction.compacted_content
  return event.content


def _serialized_size(events: list[Event]) -> int:
  """Size of the events as they would appear in a request, in characters.

  Measures whole content parts rather than text alone. A tool response is
  content the request carries in full, so a size comparison that counts only
  text parts reads a tool-heavy turn as nearly empty.

  Args:
    events: The events to measure.

  Returns:
    The summed JSON length of the content each event contributes.
  """
  total = 0
  for event in events:
    content = _request_content(event)
    if content is not None:
      total += len(content.model_dump_json(exclude_none=True, fallback=str))
  return total


def _prompt_chars_saved(*, events: list[Event], compaction_event: Event) -> int:
  """Characters this compaction removes from the assembled request.

  Negative when the compaction grows the request instead. The size is read
  from the assembler rather than from the range, because the two disagree: raw
  events inside an earlier compaction's range are already absent from the
  request, so a range that re-includes them saves less than its own size,
  while a summary that supersedes an earlier one saves more.

  Args:
    events: The session events the compaction would be appended to.
    compaction_event: The compaction to price.

  Returns:
    The request size before the compaction minus the size after it.
  """
  # Deferred import: contents depends on agents.invocation_context which
  # imports from apps, so a top-level import would create a circular dependency.
  from ..flows.llm_flows.context._compaction import _process_compaction_events

  before = _process_compaction_events(events)
  after = _process_compaction_events(events + [compaction_event])
  return _serialized_size(before) - _serialized_size(after)


async def _summarize_events_with_trace(
    *,
    session: Session,
    config: EventsCompactionConfig,
    events: list[Event],
    events_to_compact: list[Event],
    trigger: str,
    abort_signal: asyncio.Event | None = None,
) -> Event | None:
  """Summarizes events within a trace span labeled for compaction."""
  if config.summarizer is None or (
      abort_signal is not None and abort_signal.is_set()
  ):
    return None

  async def _maybe_summarize_with_abort() -> Event | None:
    assert config.summarizer is not None
    if abort_signal is None:
      return await config.summarizer.maybe_summarize_events(
          events=events_to_compact
      )
    summarize_task = asyncio.create_task(
        config.summarizer.maybe_summarize_events(events=events_to_compact)
    )
    abort_task = asyncio.create_task(abort_signal.wait())
    try:
      await asyncio.wait(
          {summarize_task, abort_task}, return_when=asyncio.FIRST_COMPLETED
      )
      if abort_signal.is_set():
        return None
      return await summarize_task
    finally:
      for task in (abort_task, summarize_task):
        if not task.done():
          task.cancel()
      await asyncio.gather(abort_task, summarize_task, return_exceptions=True)

  attributes = _build_compaction_attributes(
      session_id=session.id,
      trigger=trigger,
      summarizer_type=type(config.summarizer).__name__,
      event_count=len(events_to_compact),
      token_threshold=config.token_threshold,
      event_retention_size=config.event_retention_size,
      compaction_interval=config.compaction_interval,
      overlap_size=config.overlap_size,
  )

  with tracer.start_as_current_span(f'compact_events {trigger}') as span:
    span.set_attributes(attributes)
    try:
      compaction_event = await _maybe_summarize_with_abort()
    except Exception as e:  # pylint: disable=broad-exception-caught
      # The full history is still usable, so a failure must not end the turn.
      # Nothing unwinds past the span, so without an explicit status it would
      # be recorded as a successful compaction.
      span.record_exception(e)
      span.set_status(Status(StatusCode.ERROR, type(e).__name__))
      span.set_attribute(ERROR_TYPE, resolve_error_type(e))
      logger.warning(
          'Event compaction failed; continuing with the uncompacted history.',
          exc_info=True,
      )
      return None
    span.set_attributes(_build_compaction_result_attributes(compaction_event))
    if compaction_event is not None:
      _instrumentation.count_compaction()
      chars_saved = _prompt_chars_saved(
          events=events, compaction_event=compaction_event
      )
      span.set_attribute('gen_ai.compaction.prompt_chars_saved', chars_saved)
      if chars_saved < 0:
        logger.info(
            'Compaction grew the request by %d characters: the summary of %d'
            ' events is larger than what it replaced.',
            -chars_saved,
            len(events_to_compact),
        )
    return compaction_event


def _count_chars_in_content(content: types.Content | None) -> int:
  """Returns the number of characters in a content object."""
  total_chars = 0
  if content and content.parts:
    for part in content.parts:
      if part.text:
        total_chars += len(part.text)
      if part.function_call:
        total_chars += len(part.function_call.name or '')
        if part.function_call.args:
          try:
            total_chars += len(json.dumps(part.function_call.args))
          except Exception:  # pylint: disable=broad-exception-caught
            logger.debug(
                'Failed to serialize function_call.args, falling back to str',
                exc_info=True,
            )
            total_chars += len(str(part.function_call.args))
      if part.function_response:
        total_chars += len(part.function_response.name or '')
        if part.function_response.response:
          try:
            total_chars += len(json.dumps(part.function_response.response))
          except Exception:  # pylint: disable=broad-exception-caught
            logger.debug(
                'Failed to serialize function_response.response, falling back'
                ' to str',
                exc_info=True,
            )
            total_chars += len(str(part.function_response.response))
  return total_chars


def _get_compaction_ranges(
    events: list[Event],
) -> list[tuple[int, float, float]]:
  """Return surviving (event index, start, end) ranges in event order.

  A containing range supersedes its contained ranges; identical ranges keep
  the latest event. Sorting by start, descending end and descending index puts
  every possible containing range first, so one maximum end suffices.

  Args:
    events: Events whose valid compaction ranges should be considered.

  Returns:
    Non-subsumed ranges, preserving their original event order.
  """
  ranges: list[tuple[int, float, float]] = []
  comparable: list[tuple[int, float, float]] = []
  retained: set[int] = set()
  for index, event in enumerate(events):
    compaction = event.actions.compaction if event.actions else None
    if compaction is None or compaction.compacted_content is None:
      continue
    start, end = compaction.start_timestamp, compaction.end_timestamp
    if start is None or end is None:
      continue
    item = (index, start, end)
    ranges.append(item)
    if math.isnan(start) or math.isnan(end):
      # NaN bounds neither contain another range nor are contained by one.
      retained.add(index)
    else:
      comparable.append(item)

  comparable.sort(key=lambda item: (item[1], -item[2], -item[0]))
  max_end: float | None = None
  for index, _, end in comparable:
    if max_end is None or end > max_end:
      retained.add(index)
      max_end = end
  return [item for item in ranges if item[0] in retained]


def _estimate_prompt_token_count(
    *,
    events: list[Event],
    current_branch: str | None,
    agent_name: str,
    isolation_scope: str | None = None,
) -> int | None:
  """Returns an approximate prompt token count from session events.

  This estimate mirrors the effective content-building path used by the
  contents request processor.
  """
  # Deferred import: contents depends on agents.invocation_context which
  # imports from apps, so a top-level import would create a circular dependency.
  from ..flows.llm_flows.context import _contents

  effective_contents = _contents._get_contents(
      current_branch=current_branch,
      events=events,
      agent_name=agent_name,
      isolation_scope=isolation_scope,
  )
  total_chars = 0
  for content in effective_contents:
    total_chars += _count_chars_in_content(content)

  if total_chars <= 0:
    return None

  # Rough estimate: 4 characters per token.
  return total_chars // 4


def _earlier_calls_answered_by(events: list[Event], start: int) -> list[Event]:
  """Returns the calls before `start` that `events[start:]` responds to.

  Contents assembly drops a function response whose call it cannot see, so
  estimating `events[start:]` alone would miss a long-running tool's result.
  Each returned event keeps only the answered calls, so the other calls it
  made are not mistaken for unanswered ones.

  Args:
    events: The session events.
    start: Index of the first event of the tail.

  Returns:
    Copies of the earlier events that made those calls, in order.
  """
  unmatched_ids: set[str] = set()
  for event in events[start:]:
    unmatched_ids |= _event_function_response_ids(event)
  for event in events[start:]:
    unmatched_ids -= _event_function_call_ids(event)
  if not unmatched_ids:
    return []

  calls: list[Event] = []
  for event in events[:start]:
    if not event.content or not event.content.parts:
      continue
    parts = [
        part
        for part in event.content.parts
        if part.function_call and part.function_call.id in unmatched_ids
    ]
    if parts:
      content = event.content.model_copy(update={'parts': parts})
      calls.append(event.model_copy(update={'content': content}))
  return calls


def _latest_prompt_token_count(
    events: list[Event],
    *,
    current_branch: str | None = None,
    agent_name: str = '',
    isolation_scope: str | None = None,
) -> int | None:
  """Returns the latest prompt token count, plus an estimate for what it misses.

  A model response reports the size of the prompt that produced it, so the
  count misses that response and everything appended after it, such as the
  tool responses it asked for. Those events are estimated and added, so a burst
  of large tool responses triggers compaction before the next request.

  When `agent_name` is given, only counts recorded by that agent are
  considered. A count belongs to whichever agent made the model call, so
  reading another agent's is reading another context: a multi-agent app whose
  turn ends in a small sub-agent otherwise measures that sub-agent forever and
  never reaches its threshold.
  """
  for index in range(len(events) - 1, -1, -1):
    event = events[index]
    if event.isolation_scope != isolation_scope:
      continue
    if event.actions and event.actions.compaction:
      # Counts at or before a summarization describe a prompt it replaced.
      break
    if (
        event.usage_metadata
        and event.usage_metadata.prompt_token_count is not None
        and (not agent_name or event.author == agent_name)
    ):
      unmeasured_token_count = _estimate_prompt_token_count(
          events=_earlier_calls_answered_by(events, index) + events[index:],
          current_branch=current_branch,
          agent_name=agent_name,
          isolation_scope=isolation_scope,
      )
      return event.usage_metadata.prompt_token_count + (
          unmeasured_token_count or 0
      )
  return _estimate_prompt_token_count(
      events=events,
      current_branch=current_branch,
      agent_name=agent_name,
      isolation_scope=isolation_scope,
  )


def _latest_compaction_event(events: list[Event]) -> Event | None:
  """Returns the latest non-subsumed compaction event by stream order."""
  ranges = _get_compaction_ranges(events)
  return events[ranges[-1][0]] if ranges else None


def _latest_compaction_end_timestamp(events: list[Event]) -> float:
  """Returns the end timestamp of the most recent compaction event."""
  latest_event = _latest_compaction_event(events)
  if not latest_event or not latest_event.actions.compaction:
    return 0.0
  if latest_event.actions.compaction.end_timestamp is None:
    return 0.0
  return latest_event.actions.compaction.end_timestamp


def _removable_prompt_chars(
    *, events: list[Event], events_to_compact: list[Event]
) -> int:
  """The most a compaction over this range could remove from the request.

  Prices the range against a summary of no length, so the answer is the whole
  saving on the table before the summarizer has written anything.

  Args:
    events: The session events the compaction would be appended to.
    events_to_compact: The range the summary would replace.

  Returns:
    The characters an empty summary of the range would remove.
  """
  timestamps = [event.timestamp for event in events_to_compact]
  weightless_summary = Event(
      author='model',
      invocation_id=Event.new_id(),
      actions=EventActions(
          compaction=EventCompaction(
              start_timestamp=min(timestamps),
              end_timestamp=max(timestamps),
              compacted_content=types.Content(role='model', parts=[]),
          )
      ),
  )
  return _prompt_chars_saved(events=events, compaction_event=weightless_summary)


def _previous_summary_chars(events: list[Event]) -> int:
  """Characters of the most recent summary, or zero if there is none."""
  latest_compaction_event = _latest_compaction_event(events)
  if latest_compaction_event is None:
    return 0
  return _serialized_size([latest_compaction_event])


def _is_range_worth_compacting(
    *, events: list[Event], events_to_compact: list[Event]
) -> bool:
  """Whether replacing this range can plausibly shrink the request.

  A summary is worth writing only when the range it replaces is larger than the
  summary will be, and the summary's size is not known until it has been paid
  for. The last summary written for this session stands in for it: output
  length is a property of the summarizer, so the one it just wrote is the only
  evidence available in advance. Before there is any such evidence the range is
  compacted on the assumption that it helps.

  This has to stay ahead of the summarizer call: refusing a summary after it
  has been written leaves the trigger where it was, so the next invocation
  pays for the same call again.

  Args:
    events: The session events the compaction would be appended to.
    events_to_compact: The range the summary would replace.

  Returns:
    True when the range can remove more than the last summary's size.
  """
  return _removable_prompt_chars(
      events=events, events_to_compact=events_to_compact
  ) > _previous_summary_chars(events)


def _has_token_threshold_config(config: EventsCompactionConfig | None) -> bool:
  """Returns whether token-threshold compaction is fully configured."""
  return bool(
      config
      and config.token_threshold is not None
      and config.event_retention_size is not None
  )


def _has_sliding_window_config(config: EventsCompactionConfig | None) -> bool:
  """Returns whether sliding-window compaction is fully configured."""
  return bool(
      config
      and config.compaction_interval is not None
      and config.overlap_size is not None
  )


def _ensure_compaction_summarizer(
    *, config: EventsCompactionConfig, agent: BaseNode
) -> None:
  """Ensures compaction config has a summarizer initialized."""
  if config.summarizer is not None:
    return

  from ..agents.llm_agent import LlmAgent

  if not isinstance(agent, LlmAgent):
    raise ValueError(
        'No LlmAgent model available for event compaction summarizer.'
    )
  config.summarizer = LlmEventSummarizer(llm=agent.canonical_model)


def _events_to_compact_for_token_threshold(
    *,
    events: list[Event],
    event_retention_size: int,
) -> list[Event]:
  """Collects token-threshold compaction candidates with rolling-summary seed.

  If a previous compaction exists, include its summary as the first event so
  the next summary can supersede it.
  """
  latest_compaction_event = _latest_compaction_event(events)
  last_compacted_end_timestamp = _latest_compaction_end_timestamp(events)

  candidate_events = [
      event
      for event in events
      if not event.actions.compaction
      and event.timestamp > last_compacted_end_timestamp
  ]
  if len(candidate_events) <= event_retention_size:
    return []

  if event_retention_size == 0:
    events_to_compact = candidate_events
  else:
    split_index = _safe_token_compaction_split_index(
        candidate_events=candidate_events,
        event_retention_size=event_retention_size,
    )
    events_to_compact = candidate_events[:split_index]
  events_to_compact = _longest_self_contained_prefix(
      events_to_compact, all_events=events
  )
  if not events_to_compact:
    return []

  if (
      latest_compaction_event
      and latest_compaction_event.actions.compaction
      and latest_compaction_event.actions.compaction.start_timestamp is not None
      and latest_compaction_event.actions.compaction.compacted_content
      is not None
  ):
    seed_event = Event(
        timestamp=latest_compaction_event.actions.compaction.start_timestamp,
        author='model',
        content=latest_compaction_event.actions.compaction.compacted_content,
        branch=latest_compaction_event.branch,
        isolation_scope=latest_compaction_event.isolation_scope,
        invocation_id=Event.new_id(),
    )
    return [seed_event] + events_to_compact

  return events_to_compact


def _event_function_call_ids(event: Event) -> set[str]:
  """Returns function call ids found in an event."""
  function_call_ids: set[str] = set()
  for function_call in event.get_function_calls():
    if function_call.id:
      function_call_ids.add(function_call.id)
  return function_call_ids


def _event_function_response_ids(event: Event) -> set[str]:
  """Returns function response ids found in an event."""
  function_response_ids: set[str] = set()
  for function_response in event.get_function_responses():
    if function_response.id:
      function_response_ids.add(function_response.id)
  return function_response_ids


def _event_resolved_response_ids(event: Event) -> set[str]:
  """Returns resolved function response ids in an event."""
  pending_in_event: set[str] = set()
  if event.actions:
    if event.actions.requested_tool_confirmations:
      pending_in_event.update(event.actions.requested_tool_confirmations)
    if event.actions.requested_auth_configs:
      pending_in_event.update(event.actions.requested_auth_configs)
  return _event_function_response_ids(event) - pending_in_event


def _provably_dead_call_ids(
    events: list[Event],
    *,
    all_events: list[Event],
    newest_invocation_id: str | None,
) -> set[str]:
  """Returns function-call ids opened in `events` that can never be answered.

  A call id qualifies once: it is not a non-HITL long-running call, nor a
  synthetic HITL call or tool-confirmation/auth request in the newest
  invocation (those are expected to stay open); no resolved function response
  with the same id exists anywhere in the session, not just the compaction
  window, so a response that lives past the window boundary still protects its
  call; and the call was not opened by the newest invocation in the session,
  which may still be in flight.
  """
  protected_ids: set[str] = set()
  answered_ids: set[str] = set()
  for event in all_events:
    is_newest_or_unscoped = (
        not event.invocation_id or event.invocation_id == newest_invocation_id
    )
    if event.long_running_tool_ids:
      if is_newest_or_unscoped:
        protected_ids.update(event.long_running_tool_ids)
      else:
        synthetic_hitl_ids = {
            fc.id
            for fc in event.get_function_calls()
            if fc.id and fc.name in _CLIENT_FUNCTION_CALL_NAMES
        }
        protected_ids.update(event.long_running_tool_ids - synthetic_hitl_ids)
    if is_newest_or_unscoped and event.actions:
      if event.actions.requested_tool_confirmations:
        protected_ids.update(event.actions.requested_tool_confirmations)
      if event.actions.requested_auth_configs:
        protected_ids.update(event.actions.requested_auth_configs)
    answered_ids |= _event_resolved_response_ids(event)

  dead_ids: set[str] = set()
  for event in events:
    if newest_invocation_id and event.invocation_id == newest_invocation_id:
      continue
    for call_id in _event_function_call_ids(event):
      if call_id not in protected_ids and call_id not in answered_ids:
        dead_ids.add(call_id)
  return dead_ids


def _longest_self_contained_prefix(
    events: list[Event], *, all_events: list[Event] | None = None
) -> list[Event]:
  """Returns the longest prefix of `events` that is safe to compact.

  Performs a single left-to-right pass tracking "open" obligations keyed by call
  id: a function call or a tool-confirmation / auth request opens one, and a
  function response with the same id closes it. Responses are applied before
  opens within each event so a response only closes an obligation opened by an
  earlier event. The prefix is safe to summarize only at points where no
  obligation is open, so the longest prefix ending at such a balanced point is
  returned.

  If that strict pass does not cover all candidate events (e.g. the window
  contains a function call whose response will never arrive, because the process
  handling it died), a second pass retries while ignoring call ids that
  `_provably_dead_call_ids` proves can never be fulfilled, so healthy events
  after a dead call can still be compacted. Without this, a single orphaned
  call permanently blocks every future compaction, since it becomes the
  first candidate event of every subsequent window once it is not covered by
  the previous one. The second pass needs the whole session as `all_events`;
  when it is omitted, only the strict pass runs.
  """

  def _pass(dead_ids: set[str]) -> int:
    open_ids: set[str] = set()
    safe_length = 0
    for index, event in enumerate(events):
      open_ids -= _event_function_response_ids(event)
      open_ids |= _event_function_call_ids(event) - dead_ids
      if event.actions:
        if event.actions.requested_tool_confirmations:
          open_ids |= set(event.actions.requested_tool_confirmations) - dead_ids
        if event.actions.requested_auth_configs:
          open_ids |= set(event.actions.requested_auth_configs) - dead_ids
      if not open_ids:
        safe_length = index + 1
    return safe_length

  safe_length = _pass(set())
  if safe_length == len(events):
    return events
  if all_events is None:
    return events[:safe_length]

  if safe_length > 0 and (
      events[safe_length - 1].invocation_id != events[safe_length].invocation_id
  ):
    return events[:safe_length]

  newest_invocation_id = None
  for event in reversed(all_events):
    if event.invocation_id and not (event.actions and event.actions.compaction):
      newest_invocation_id = event.invocation_id
      break

  dead_ids = _provably_dead_call_ids(
      events, all_events=all_events, newest_invocation_id=newest_invocation_id
  )
  if not dead_ids:
    return events[:safe_length]

  return events[: max(safe_length, _pass(dead_ids))]


def _safe_token_compaction_split_index(
    *,
    candidate_events: list[Event],
    event_retention_size: int,
) -> int:
  """Returns a split index that avoids orphaning retained tool responses.

  Retained events (tail of candidate events) may contain function responses.
  If their matching function call events are in the compacted prefix, contents
  assembly can fail. This method shifts the split earlier so matching function
  call events are retained together with their responses.

  Iterates backwards through candidate_events once, maintaining a running set
  of unmatched response IDs. The latest valid split point where no unmatched
  responses remain is returned.
  """
  initial_split = len(candidate_events) - event_retention_size
  if initial_split <= 0:
    return 0

  unmatched_response_ids: set[str] = set()
  best_split = 0

  for i in range(len(candidate_events) - 1, -1, -1):
    event = candidate_events[i]
    unmatched_response_ids.update(_event_function_response_ids(event))
    call_ids = _event_function_call_ids(event)
    unmatched_response_ids -= call_ids

    if not unmatched_response_ids and i <= initial_split:
      best_split = i
      break

  return best_split


async def _run_compaction_for_token_threshold_config(
    *,
    config: EventsCompactionConfig | None,
    session: Session,
    session_service: BaseSessionService,
    agent: BaseNode,
    agent_name: str = '',
    current_branch: str | None = None,
    isolation_scope: str | None = None,
    abort_signal: asyncio.Event | None = None,
) -> bool:
  """Runs token-threshold compaction for a provided compaction config."""
  if abort_signal is not None and abort_signal.is_set():
    return False
  if not _has_token_threshold_config(config):
    return False
  if config is None:
    return False

  if config.token_threshold is None or config.event_retention_size is None:
    return False

  # Drop rewound invocations so the summary covers only live events, consistent
  # with prompt building and sliding-window compaction (all route through
  # _apply_rewinds); otherwise rewound content would leak back into future
  # prompts via the compaction summary. Also filter by isolation_scope so
  # isolated task/sub-agent events never leak into or out of another scope.
  rewound_events = _apply_rewinds(session.events)
  events = [e for e in rewound_events if e.isolation_scope == isolation_scope]

  prompt_token_count = _latest_prompt_token_count(
      rewound_events,
      current_branch=current_branch,
      agent_name=agent_name,
      isolation_scope=isolation_scope,
  )
  if prompt_token_count is None or prompt_token_count < config.token_threshold:
    return False

  events_to_compact = _events_to_compact_for_token_threshold(
      events=events,
      event_retention_size=config.event_retention_size,
  )
  if not events_to_compact:
    return False

  if not _is_range_worth_compacting(
      events=events, events_to_compact=events_to_compact
  ):
    return False

  _ensure_compaction_summarizer(config=config, agent=agent)
  if config.summarizer is None:
    return False

  compaction_event = await _summarize_events_with_trace(
      session=session,
      config=config,
      events=events,
      events_to_compact=events_to_compact,
      trigger='token_threshold',
      abort_signal=abort_signal,
  )
  if compaction_event and not (
      abort_signal is not None and abort_signal.is_set()
  ):
    compaction_event.isolation_scope = isolation_scope
    await session_service.append_event(session=session, event=compaction_event)
    logger.debug('Token-threshold event compactor finished.')
    return True
  return False


async def _run_compaction_for_sliding_window(
    app: App,
    session: Session,
    session_service: BaseSessionService,
    *,
    abort_signal: asyncio.Event | None = None,
) -> AsyncGenerator[Event, None]:
  """Runs sliding-window compaction with the app's compaction config."""
  if app.root_agent is None:
    return
  async with aclosing(
      _run_compaction_for_sliding_window_config(
          config=app.events_compaction_config,
          session=session,
          session_service=session_service,
          agent=app.root_agent,
          abort_signal=abort_signal,
      )
  ) as compaction_events:
    async for compaction_event in compaction_events:
      yield compaction_event


async def _run_compaction_for_sliding_window_config(
    *,
    config: EventsCompactionConfig | None,
    session: Session,
    session_service: BaseSessionService,
    agent: BaseNode,
    abort_signal: asyncio.Event | None = None,
) -> AsyncGenerator[Event, None]:
  """Runs sliding-window compaction over the session's events.

  Compaction triggers once `compaction_interval` new invocations have completed
  since the end of the last compaction. The window to summarize starts
  `overlap_size` invocations before the first new one, so consecutive summaries
  overlap and keep continuity, and it ends with the last new invocation.
  Rewound invocations and earlier compaction events are left out, and the
  window is trimmed to its longest prefix that leaves no answerable function
  call or pending confirmation unanswered. The configured summarizer turns that
  window into a single event carrying an `EventCompaction`.

  With `compaction_interval = 2` and `overlap_size = 1`, invocations 1 and 2
  are summarized together. Invocation 3 alone triggers nothing. Once invocation
  4 completes there are two new invocations again, and the next summary covers
  invocations 2 through 4.

  Token-threshold compaction takes precedence: when it is configured and it
  produces a summary, this returns without a sliding-window summary.

  Args:
    config: The compaction config to apply. None means no compaction.
    session: The session containing events to compact.
    session_service: The session service, used by the token-threshold path,
      which appends its own event directly.
    agent: The root agent, whose model builds the summarizer when the config has
      none.
    abort_signal: Optional signal that cancels in-flight summarization.

  Yields:
    The sliding-window compaction event, if one is produced. The caller (the
    runner loop) is responsible for appending it to the session, so that
    persistence of this event stays at the runtime's synchronization point.
  """
  if abort_signal is not None and abort_signal.is_set():
    return
  # Drop rewound invocations first so the summary covers only live events. This
  # keeps the compactor consistent with prompt building (the contents processor
  # also applies rewinds); otherwise rewound content would leak back into future
  # prompts via the compaction summary. Also exclude isolated task/sub-agent
  # events so their private turns do not leak into the root session summary.
  events = [
      e for e in _apply_rewinds(session.events) if e.isolation_scope is None
  ]
  if not events:
    return

  if config is None:
    return

  # Prefer token-threshold compaction if configured and triggered.
  if _has_token_threshold_config(config):
    token_compacted = await _run_compaction_for_token_threshold_config(
        config=config,
        session=session,
        session_service=session_service,
        agent=agent,
        abort_signal=abort_signal,
    )
    if token_compacted:
      return

  if not _has_sliding_window_config(config):
    return

  if config.compaction_interval is None or config.overlap_size is None:
    return

  # Find the last compaction event and its range.
  last_compacted_end_timestamp = 0.0
  for event in reversed(events):
    if event.actions.compaction and event.actions.compaction.end_timestamp:
      last_compacted_end_timestamp = event.actions.compaction.end_timestamp
      break

  # Get unique invocation IDs and their latest timestamps.
  invocation_latest_timestamps: dict[str, float] = {}
  for event in events:
    # Only consider non-compaction events for unique invocation IDs.
    if event.invocation_id and not event.actions.compaction:
      invocation_latest_timestamps[event.invocation_id] = max(
          invocation_latest_timestamps.get(event.invocation_id, 0.0),
          event.timestamp,
      )

  unique_invocation_ids = list(invocation_latest_timestamps.keys())

  # Determine which invocations are new since the last compaction.
  new_invocation_ids = [
      inv_id
      for inv_id in unique_invocation_ids
      if invocation_latest_timestamps[inv_id] > last_compacted_end_timestamp
  ]

  if len(new_invocation_ids) < config.compaction_interval:
    return  # Not enough new invocations to trigger compaction.

  # Determine the range of invocations to compact.
  # The end of the compaction range is the last of the new invocations.
  end_inv_id = new_invocation_ids[-1]

  # The start of the compaction range is overlap_size invocations before
  # the first of the new invocations.
  first_new_inv_id = new_invocation_ids[0]
  first_new_inv_idx = unique_invocation_ids.index(first_new_inv_id)

  start_idx = max(0, first_new_inv_idx - config.overlap_size)
  start_inv_id = unique_invocation_ids[start_idx]

  # Find the index of the last event with end_inv_id.
  last_event_idx = -1
  for i in range(len(events) - 1, -1, -1):
    if events[i].invocation_id == end_inv_id:
      last_event_idx = i
      break

  events_to_compact = []
  # Trim events_to_compact to include all events up to and including the
  # last event of end_inv_id.
  if last_event_idx != -1:
    # Find the index of the first event of start_inv_id in events.
    first_event_start_inv_idx = -1
    for i, event in enumerate(events):
      if event.invocation_id == start_inv_id:
        first_event_start_inv_idx = i
        break
    if first_event_start_inv_idx != -1:
      events_to_compact = events[first_event_start_inv_idx : last_event_idx + 1]
      # Filter out any existing compaction events from the list.
      events_to_compact = [
          e for e in events_to_compact if not e.actions.compaction
      ]
      events_to_compact = _longest_self_contained_prefix(
          events_to_compact, all_events=events
      )

  if not events_to_compact:
    return

  if not _is_range_worth_compacting(
      events=events, events_to_compact=events_to_compact
  ):
    return

  _ensure_compaction_summarizer(config=config, agent=agent)
  if config.summarizer is None:
    return

  compaction_event = await _summarize_events_with_trace(
      session=session,
      config=config,
      events=events,
      events_to_compact=events_to_compact,
      trigger='sliding_window',
      abort_signal=abort_signal,
  )
  logger.debug('Event compactor finished.')
  if compaction_event:
    yield compaction_event
