# Copyright 2026 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""An artifact service implementation using Google Cloud Storage (GCS).

The blob name format used depends on whether the filename has a user namespace:
  - For files with user namespace (starting with "user:"):
    {app_name}/{user_id}/user/{filename}/{version}
  - For regular session-scoped files:
    {app_name}/{user_id}/{session_id}/{filename}/{version}
"""

from __future__ import annotations

import asyncio
import datetime
import logging
from typing import Any
from typing import cast
from typing import Literal
import urllib.parse

from google.genai import types
from typing_extensions import override

from . import artifact_util
from ..errors.input_validation_error import InputValidationError
from .base_artifact_service import ArtifactVersion
from .base_artifact_service import BaseArtifactService
from .base_artifact_service import ensure_part

logger = logging.getLogger("google_adk." + __name__)

_GCS_DISPLAY_NAME_METADATA_KEY = "adkDisplayName"
_GCS_IS_TEXT_METADATA_KEY = "adkIsText"
_GCS_FILE_URI_METADATA_KEY = "adkFileUri"
_GCS_FILE_MIME_TYPE_METADATA_KEY = "adkFileMimeType"
_LEGACY_GCS_FILE_URI_METADATA_KEY = "file_uri"
# Blob metadata keys reserved for this service's own bookkeeping. They are
# dropped from custom_metadata on save and hidden from it on read.
_INTERNAL_METADATA_KEYS = frozenset({
    _GCS_DISPLAY_NAME_METADATA_KEY,
    _GCS_IS_TEXT_METADATA_KEY,
    _GCS_FILE_URI_METADATA_KEY,
    _GCS_FILE_MIME_TYPE_METADATA_KEY,
    _LEGACY_GCS_FILE_URI_METADATA_KEY,
})
_MAX_SAVE_VERSION_ATTEMPTS = 10


def _user_metadata(
    blob_metadata: dict[str, Any] | None,
) -> dict[str, Any]:
  """Returns only the metadata the caller supplied on save."""
  if not blob_metadata:
    return {}
  return {
      key: value
      for key, value in blob_metadata.items()
      if key not in _INTERNAL_METADATA_KEYS
  }


def _get_file_uri(
    blob_metadata: dict[str, Any] | None,
) -> str | None:
  """Returns the file URI recorded on the blob, checking legacy keys too."""
  if not blob_metadata:
    return None
  return blob_metadata.get(_GCS_FILE_URI_METADATA_KEY) or blob_metadata.get(
      _LEGACY_GCS_FILE_URI_METADATA_KEY
  )


def _parse_version(blob_name: str, prefix: str) -> int | None:
  """Extracts the version of an artifact from one of its blob names.

  GCS has a flat namespace, so listing by prefix is a plain string match with
  no notion of nesting depth. Because filenames are allowed to contain "/",
  the prefix of an artifact is also a prefix of every artifact nested under it:
  scanning "a/" to find versions of "a" also returns "a/b/3", which is version
  3 of the distinct artifact "a/b".

  A blob only holds a version of the artifact denoted by ``prefix`` when its
  name is exactly ``{prefix}{version}``, so anything with a further "/" in it
  belongs to some other artifact and must be skipped.

  Args:
      blob_name: The full name of the blob, which must start with ``prefix``.
      prefix: The blob prefix of the artifact, including the trailing "/".

  Returns:
      The version number, or None if the blob does not hold a version of this
      artifact.
  """
  suffix = blob_name[len(prefix) :]
  if "/" in suffix:
    # Belongs to a distinct artifact nested under this one.
    return None
  # int() also accepts surrounding whitespace, underscores and non-ASCII
  # digits, none of which _get_blob_name can produce.
  if not (suffix.isascii() and suffix.isdigit()):
    logger.warning(
        "Skipping blob %s because it does not end with a version number.",
        blob_name,
    )
    return None
  return int(suffix)


class GcsArtifactService(BaseArtifactService):
  """An artifact service implementation using Google Cloud Storage (GCS)."""

  def __init__(self, bucket_name: str, **kwargs: Any):
    """Initializes the GcsArtifactService.

    Args:
        bucket_name: The name of the bucket to use.
        **kwargs: Keyword arguments to pass to the Google Cloud Storage client.
    """
    from google.cloud import storage  # pylint: disable=g-import-not-at-top

    self.bucket_name = bucket_name
    self.storage_client = storage.Client(**kwargs)
    self.bucket = self.storage_client.bucket(self.bucket_name)

  @override
  async def save_artifact(
      self,
      *,
      app_name: str,
      user_id: str,
      filename: str,
      artifact: types.Part | dict[str, Any],
      session_id: str | None = None,
      custom_metadata: dict[str, Any] | None = None,
  ) -> int:
    return await asyncio.to_thread(
        self._save_artifact,
        app_name,
        user_id,
        session_id,
        filename,
        artifact,
        custom_metadata,
    )

  @override
  async def load_artifact(
      self,
      *,
      app_name: str,
      user_id: str,
      filename: str,
      session_id: str | None = None,
      version: int | None = None,
  ) -> types.Part | None:
    return await asyncio.to_thread(
        self._load_artifact,
        app_name,
        user_id,
        session_id,
        filename,
        version,
    )

  @override
  async def list_artifact_keys(
      self, *, app_name: str, user_id: str, session_id: str | None = None
  ) -> list[str]:
    return await asyncio.to_thread(
        self._list_artifact_keys,
        app_name,
        user_id,
        session_id,
    )

  @override
  async def delete_artifact(
      self,
      *,
      app_name: str,
      user_id: str,
      filename: str,
      session_id: str | None = None,
  ) -> None:
    return await asyncio.to_thread(
        self._delete_artifact,
        app_name,
        user_id,
        session_id,
        filename,
    )

  @override
  async def list_versions(
      self,
      *,
      app_name: str,
      user_id: str,
      filename: str,
      session_id: str | None = None,
  ) -> list[int]:
    return await asyncio.to_thread(
        self._list_versions,
        app_name,
        user_id,
        session_id,
        filename,
    )

  def _file_has_user_namespace(self, filename: str) -> bool:
    """Checks if the filename has a user namespace.

    Args:
        filename: The filename to check.

    Returns:
        True if the filename has a user namespace (starts with "user:"),
        False otherwise.
    """
    return filename.startswith("user:")

  def _get_blob_prefix(
      self,
      app_name: str,
      user_id: str,
      filename: str,
      session_id: str | None = None,
  ) -> str:
    """Constructs the blob name prefix in GCS for a given artifact."""
    artifact_util.validate_path_segment(app_name, "app_name")
    artifact_util.validate_path_segment(user_id, "user_id")
    if self._file_has_user_namespace(filename):
      return f"{app_name}/{user_id}/user/{filename}"

    if session_id is None:
      raise InputValidationError(
          "Session ID must be provided for session-scoped artifacts."
      )
    artifact_util.validate_path_segment(session_id, "session_id")
    return f"{app_name}/{user_id}/{session_id}/{filename}"

  def _get_blob_name(
      self,
      app_name: str,
      user_id: str,
      filename: str,
      version: int,
      session_id: str | None = None,
  ) -> str:
    """Constructs the blob name in GCS.

    Args:
        app_name: The name of the application.
        user_id: The ID of the user.
        filename: The name of the artifact file.
        version: The version of the artifact.
        session_id: The ID of the session.

    Returns:
        The constructed blob name in GCS.
    """
    return (
        f"{self._get_blob_prefix(app_name, user_id, filename, session_id)}/{version}"
    )

  def _save_artifact(
      self,
      app_name: str,
      user_id: str,
      session_id: str | None,
      filename: str,
      artifact: types.Part | dict[str, Any],
      custom_metadata: dict[str, Any] | None = None,
  ) -> int:
    from google.cloud import exceptions  # pylint: disable=g-import-not-at-top

    if not self._file_has_user_namespace(filename):
      if session_id is None:
        raise InputValidationError(
            "Session ID must be provided for session-scoped artifacts."
        )
      artifact_util._validate_session_id_for_flat_storage(session_id)

    artifact = ensure_part(artifact)
    blob_metadata = {
        k: str(v) for k, v in _user_metadata(custom_metadata).items()
    }
    if artifact.inline_data and artifact.inline_data.display_name:
      blob_metadata[_GCS_DISPLAY_NAME_METADATA_KEY] = (
          artifact.inline_data.display_name
      )
    elif artifact.inline_data is None and artifact.text is not None:
      # Flag text artifacts so they can be reconstructed as Part(text=...) on
      # load instead of Part.from_bytes() (which would only populate
      # inline_data).
      blob_metadata[_GCS_IS_TEXT_METADATA_KEY] = "true"

    data: str | bytes
    content_type: str | None
    if artifact.inline_data:
      if artifact.inline_data.data is None:
        raise InputValidationError("Artifact inline_data must contain data.")
      data = artifact.inline_data.data
      content_type = artifact.inline_data.mime_type
    elif artifact.text is not None:
      data = artifact.text
      content_type = "text/plain"
    elif artifact.file_data:
      file_data = artifact.file_data
      file_uri = file_data.file_uri
      if not file_uri:
        raise InputValidationError("Artifact file_data must have a file_uri.")
      if artifact_util.is_artifact_ref(artifact):
        parsed_uri = artifact_util.parse_artifact_uri(file_uri)
        if not parsed_uri:
          raise InputValidationError(
              f"Invalid artifact reference URI: {file_uri}"
          )
        artifact_util.validate_artifact_reference_scope(
            app_name=app_name,
            user_id=user_id,
            session_id=session_id,
            parsed_uri=parsed_uri,
        )
      # Store the URI and mime_type (if any) as blob metadata; no content to upload.
      blob_metadata[_GCS_FILE_URI_METADATA_KEY] = file_uri
      if file_data.mime_type:
        blob_metadata[_GCS_FILE_MIME_TYPE_METADATA_KEY] = file_data.mime_type
      data = b""
      content_type = file_data.mime_type or None
    else:
      raise InputValidationError(
          "Artifact must have either inline_data or text."
      )

    versions = self._list_versions(
        app_name=app_name,
        user_id=user_id,
        session_id=session_id,
        filename=filename,
    )
    version = 0 if not versions else max(versions) + 1

    # Listing the versions does not reserve one, so a concurrent save can pick
    # the same number. if_generation_match=0 makes the upload a create, which
    # fails instead of overwriting the version the other save just wrote; take
    # the next number and try again. Every attempt re-uploads the payload, so
    # the attempts are capped and sustained contention surfaces as the last
    # precondition failure rather than as an unbounded retry loop.
    attempts_left = _MAX_SAVE_VERSION_ATTEMPTS
    while True:
      blob_name = self._get_blob_name(
          app_name, user_id, filename, version, session_id
      )
      blob = self.bucket.blob(blob_name)
      if blob_metadata:
        blob.metadata = blob_metadata
      try:
        blob.upload_from_string(
            data=data,
            content_type=content_type,
            if_generation_match=0,
        )
      except exceptions.PreconditionFailed:
        attempts_left -= 1
        if not attempts_left:
          raise
        version += 1
        continue
      return version

  def _load_artifact(
      self,
      app_name: str,
      user_id: str,
      session_id: str | None,
      filename: str,
      version: int | None = None,
      *,
      max_depth: int = artifact_util._MAX_ARTIFACT_REFERENCE_DEPTH,
  ) -> types.Part | None:
    if version is None:
      versions = self._list_versions(
          app_name=app_name,
          user_id=user_id,
          session_id=session_id,
          filename=filename,
      )
      if not versions:
        return None
      version = max(versions)

    blob_name = self._get_blob_name(
        app_name, user_id, filename, version, session_id
    )
    blob = self.bucket.get_blob(blob_name)
    if not blob:
      return None

    # If the artifact was saved as a file_data URI reference, restore or resolve it.
    file_uri = _get_file_uri(blob.metadata)

    if file_uri:
      if file_uri.startswith("artifact://"):
        parsed_uri = artifact_util.resolve_artifact_reference(
            file_uri=file_uri,
            app_name=app_name,
            user_id=user_id,
            session_id=session_id,
            remaining_depth=max_depth,
        )
        return self._load_artifact(
            app_name=parsed_uri.app_name,
            user_id=parsed_uri.user_id,
            session_id=parsed_uri.session_id,
            filename=parsed_uri.filename,
            version=parsed_uri.version,
            max_depth=max_depth - 1,
        )
      mime_type = None
      if blob.metadata:
        mime_type = blob.metadata.get(_GCS_FILE_MIME_TYPE_METADATA_KEY)
      if mime_type is None:
        mime_type = blob.content_type or None
      return types.Part(
          file_data=types.FileData(
              file_uri=file_uri,
              mime_type=mime_type,
          )
      )

    artifact_bytes = blob.download_as_bytes()
    if blob.metadata and blob.metadata.get(_GCS_IS_TEXT_METADATA_KEY) == "true":
      return types.Part(text=artifact_bytes.decode("utf-8"))
    display_name = None
    if blob.metadata:
      display_name = blob.metadata.get(_GCS_DISPLAY_NAME_METADATA_KEY)
    if display_name:
      return types.Part(
          inline_data=types.Blob(
              mime_type=blob.content_type,
              data=artifact_bytes,
              display_name=display_name,
          )
      )
    artifact = types.Part.from_bytes(
        data=artifact_bytes, mime_type=blob.content_type
    )
    if artifact_util._is_rewind_tombstone(artifact):
      return None
    return artifact

  def _list_artifact_keys(
      self, app_name: str, user_id: str, session_id: str | None
  ) -> list[str]:
    artifact_util.validate_path_segment(app_name, "app_name")
    artifact_util.validate_path_segment(user_id, "user_id")
    if session_id is not None:
      artifact_util.validate_path_segment(session_id, "session_id")
    filenames = set()

    if session_id:
      session_prefix = f"{app_name}/{user_id}/{session_id}/"
      session_blobs = self.storage_client.list_blobs(
          self.bucket, prefix=session_prefix
      )
      for blob in session_blobs:
        # blob.name is like session_prefix/filename/version
        # or session_prefix/path/to/filename/version
        # we need to extract filename including slashes, but remove prefix
        # and /version
        fn_and_version = blob.name[len(session_prefix) :]
        filename = "/".join(fn_and_version.split("/")[:-1])
        filenames.add(filename)

    user_namespace_prefix = f"{app_name}/{user_id}/user/"
    user_namespace_blobs = self.storage_client.list_blobs(
        self.bucket, prefix=user_namespace_prefix
    )
    for blob in user_namespace_blobs:
      # blob.name is like user_namespace_prefix/filename/version
      fn_and_version = blob.name[len(user_namespace_prefix) :]
      filename = "/".join(fn_and_version.split("/")[:-1])
      filenames.add(filename)

    return sorted(list(filenames))

  def _delete_artifact(
      self,
      app_name: str,
      user_id: str,
      session_id: str | None,
      filename: str,
  ) -> None:
    versions = self._list_versions(
        app_name=app_name,
        user_id=user_id,
        session_id=session_id,
        filename=filename,
    )
    for version in versions:
      blob_name = self._get_blob_name(
          app_name, user_id, filename, version, session_id
      )
      blob = self.bucket.blob(blob_name)
      blob.delete()
    return

  def _list_versions(
      self,
      app_name: str,
      user_id: str,
      session_id: str | None,
      filename: str,
  ) -> list[int]:
    """Lists all available versions of an artifact.

    This method retrieves all versions of a specific artifact by querying GCS
    blobs
    that match the constructed blob name prefix.

    Args:
        app_name: The name of the application.
        user_id: The ID of the user who owns the artifact.
        session_id: The ID of the session (ignored for user-namespaced files).
        filename: The name of the artifact file.

    Returns:
        A list of version numbers (integers) available for the specified
        artifact, in ascending order.
        Returns an empty list if no versions are found.
    """
    prefix = (
        f"{self._get_blob_prefix(app_name, user_id, filename, session_id)}/"
    )
    blobs = self.storage_client.list_blobs(self.bucket, prefix=prefix)
    versions = []
    for blob in blobs:
      version = _parse_version(blob.name, prefix)
      if version is None:
        continue

      versions.append(version)

    versions.sort()
    return versions

  def _get_artifact_version_sync(
      self,
      app_name: str,
      user_id: str,
      session_id: str | None,
      filename: str,
      version: int | None = None,
  ) -> ArtifactVersion | None:
    if version is None:
      versions = self._list_versions(
          app_name=app_name,
          user_id=user_id,
          session_id=session_id,
          filename=filename,
      )
      if not versions:
        return None
      version = max(versions)

    blob_name = self._get_blob_name(
        app_name, user_id, filename, version, session_id
    )
    blob = self.bucket.get_blob(blob_name)

    if not blob:
      return None

    canonical_uri = f"gs://{self.bucket_name}/{blob.name}"

    return ArtifactVersion(
        version=version,
        canonical_uri=canonical_uri,
        create_time=blob.time_created.timestamp(),
        mime_type=blob.content_type,
        custom_metadata=_user_metadata(blob.metadata),
    )

  def _list_artifact_versions_sync(
      self,
      app_name: str,
      user_id: str,
      session_id: str | None,
      filename: str,
  ) -> list[ArtifactVersion]:
    """Lists all versions and their metadata of an artifact."""
    prefix = (
        f"{self._get_blob_prefix(app_name, user_id, filename, session_id)}/"
    )
    blobs = self.storage_client.list_blobs(self.bucket, prefix=prefix)
    artifact_versions = []
    for blob in blobs:
      version = _parse_version(blob.name, prefix)
      if version is None:
        continue

      canonical_uri = f"gs://{self.bucket_name}/{blob.name}"
      av = ArtifactVersion(
          version=version,
          canonical_uri=canonical_uri,
          create_time=blob.time_created.timestamp(),
          mime_type=blob.content_type,
          custom_metadata=_user_metadata(blob.metadata),
      )
      artifact_versions.append(av)

    artifact_versions.sort(key=lambda x: x.version)
    return artifact_versions

  @override
  async def list_artifact_versions(
      self,
      *,
      app_name: str,
      user_id: str,
      filename: str,
      session_id: str | None = None,
  ) -> list[ArtifactVersion]:
    return await asyncio.to_thread(
        self._list_artifact_versions_sync,
        app_name,
        user_id,
        session_id,
        filename,
    )

  @override
  async def get_artifact_version(
      self,
      *,
      app_name: str,
      user_id: str,
      filename: str,
      session_id: str | None = None,
      version: int | None = None,
  ) -> ArtifactVersion | None:
    return await asyncio.to_thread(
        self._get_artifact_version_sync,
        app_name,
        user_id,
        session_id,
        filename,
        version,
    )

  def _get_authenticated_url_sync(
      self,
      app_name: str,
      user_id: str,
      session_id: str | None,
      filename: str,
      version: int | None = None,
      *,
      max_depth: int = artifact_util._MAX_ARTIFACT_REFERENCE_DEPTH,
  ) -> str | None:
    """Generates an authenticated browser URL for an artifact."""
    if version is None:
      versions = self._list_versions(
          app_name=app_name,
          user_id=user_id,
          session_id=session_id,
          filename=filename,
      )
      if not versions:
        return None
      version = max(versions)

    blob_name = self._get_blob_name(
        app_name, user_id, filename, version, session_id
    )
    blob = self.bucket.get_blob(blob_name)
    if not blob:
      return None

    file_uri = _get_file_uri(blob.metadata)

    if file_uri:
      if file_uri.startswith("artifact://"):
        parsed_uri = artifact_util.resolve_artifact_reference(
            file_uri=file_uri,
            app_name=app_name,
            user_id=user_id,
            session_id=session_id,
            remaining_depth=max_depth,
        )
        return self._get_authenticated_url_sync(
            app_name=parsed_uri.app_name,
            user_id=parsed_uri.user_id,
            session_id=parsed_uri.session_id,
            filename=parsed_uri.filename,
            version=parsed_uri.version,
            max_depth=max_depth - 1,
        )
      return None

    quoted_blob_name = urllib.parse.quote(blob_name, safe="/")
    return f"https://storage.cloud.google.com/{self.bucket_name}/{quoted_blob_name}"

  async def get_authenticated_url(
      self,
      *,
      app_name: str,
      user_id: str,
      filename: str,
      session_id: str | None = None,
      version: int | None = None,
  ) -> str | None:
    """Generates an authenticated browser URL for an artifact.

    The URL returned requires the user to be authenticated with a Google
    Account that has read permission for the object.

    Args:
        app_name: The name of the application.
        user_id: The ID of the user who owns the artifact.
        filename: The name of the artifact file.
        session_id: The ID of the session (ignored for user-namespaced files).
        version: The version of the artifact. If None, the latest version will
          be used.

    Returns:
        The authenticated GCS URL (https://storage.cloud.google.com/...), or
        None if the artifact does not exist.
    """
    return await asyncio.to_thread(
        self._get_authenticated_url_sync,
        app_name,
        user_id,
        session_id,
        filename,
        version,
    )

  def _get_signed_url_sync(
      self,
      app_name: str,
      user_id: str,
      session_id: str | None,
      filename: str,
      version: int | None = None,
      expiration: datetime.datetime | datetime.timedelta | int | None = None,
      method: str = "GET",
      signing_version: Literal["v2", "v4"] | None = None,
      extra_signing_options: dict[str, Any] | None = None,
      *,
      max_depth: int = artifact_util._MAX_ARTIFACT_REFERENCE_DEPTH,
  ) -> str | None:
    """Generates a time-limited signed URL for an artifact."""
    if version is None:
      versions = self._list_versions(
          app_name=app_name,
          user_id=user_id,
          session_id=session_id,
          filename=filename,
      )
      if not versions:
        return None
      version = max(versions)

    blob_name = self._get_blob_name(
        app_name, user_id, filename, version, session_id
    )
    blob = self.bucket.get_blob(blob_name)
    if not blob:
      return None

    file_uri = _get_file_uri(blob.metadata)

    if file_uri:
      if file_uri.startswith("artifact://"):
        parsed_uri = artifact_util.resolve_artifact_reference(
            file_uri=file_uri,
            app_name=app_name,
            user_id=user_id,
            session_id=session_id,
            remaining_depth=max_depth,
        )
        return self._get_signed_url_sync(
            app_name=parsed_uri.app_name,
            user_id=parsed_uri.user_id,
            session_id=parsed_uri.session_id,
            filename=parsed_uri.filename,
            version=parsed_uri.version,
            expiration=expiration,
            method=method,
            signing_version=signing_version,
            extra_signing_options=extra_signing_options,
            max_depth=max_depth - 1,
        )
      return None

    if expiration is None:
      expiration = datetime.timedelta(hours=1)

    call_kwargs = dict(extra_signing_options) if extra_signing_options else {}
    if signing_version is not None:
      call_kwargs["version"] = signing_version

    return cast(
        str,
        blob.generate_signed_url(
            expiration=expiration,
            method=method,
            **call_kwargs,
        ),
    )

  async def get_signed_url(
      self,
      *,
      app_name: str,
      user_id: str,
      filename: str,
      session_id: str | None = None,
      version: int | None = None,
      expiration: datetime.datetime | datetime.timedelta | int | None = None,
      method: str = "GET",
      signing_version: Literal["v2", "v4"] | None = None,
      **kwargs: Any,
  ) -> str | None:
    """Generates a time-limited signed URL for an artifact.

    Args:
        app_name: The name of the application.
        user_id: The ID of the user who owns the artifact.
        filename: The name of the artifact file.
        session_id: The ID of the session (ignored for user-namespaced files).
        version: The version of the artifact. If None, the latest version will
          be used.
        expiration: Time when the signed URL expires (datetime, timedelta, or
          epoch seconds). Defaults to 1 hour if not specified.
        method: HTTP method allowed for the signed URL (default: "GET").
        signing_version: The signing version to use ("v2" or "v4"). Forwarded as
          `version` to `Blob.generate_signed_url`.
        **kwargs: Additional keyword arguments forwarded to
          `Blob.generate_signed_url`.

    Returns:
        The signed URL string, or None if the artifact does not exist.
    """
    return await asyncio.to_thread(
        self._get_signed_url_sync,
        app_name,
        user_id,
        session_id,
        filename,
        version,
        expiration,
        method,
        signing_version,
        kwargs,
    )
