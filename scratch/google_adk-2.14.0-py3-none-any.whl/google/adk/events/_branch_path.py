# Copyright 2026 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Hierarchical path representation for dynamic execution branches."""

from __future__ import annotations


class _BranchPath:
  """Represents a hierarchical path for execution branches.

  A path consists of dot-separated segments (e.g., 'segment1.segment2'),
  where each segment represents a node run and is typically formatted
  as 'node_name@run_id' or 'node_name'.

  Example:
    'parent_agent@1.collect_user_info_tool@2.sub_workflow'
  """

  def __init__(self, segments: list[str]):
    """Initializes a _BranchPath with a list of segments."""
    self._segments = list(segments)

  @classmethod
  def from_string(cls, path_str: str | None) -> _BranchPath:
    """Parses a _BranchPath from a dot-separated string representation."""
    if not path_str:
      return cls([])
    return cls(path_str.split("."))

  def __str__(self) -> str:
    """Returns the dot-separated string representation of the path."""
    return ".".join(self._segments)

  def __eq__(self, other: object) -> bool:
    """Returns True if segments are equal."""
    if not isinstance(other, _BranchPath):
      return NotImplemented
    return self._segments == other._segments

  @property
  def segments(self) -> list[str]:
    """Returns a copy of the path segments."""
    return list(self._segments)

  @property
  def ordered_run_ids(self) -> tuple[str, ...]:
    """Extracts all run IDs (the part after '@') in segment order.

    Example:
      - Path: 'parent@1.child@2.node'
      - Returns: ('1', '2')
    """
    ids: list[str] = []
    for segment in self._segments:
      parts = segment.rsplit("@", 1)
      if len(parts) > 1 and parts[1]:
        ids.append(parts[1])
    return tuple(ids)

  @property
  def run_ids(self) -> set[str]:
    """Extracts all run IDs (the part after '@') from all segments in the path.

    Example:
      - Path: 'parent@1.child@2.node'
      - Returns: {'1', '2'}
    """
    return set(self.ordered_run_ids)

  @property
  def parent(self) -> _BranchPath | None:
    """Returns the parent _BranchPath, or None if this is a root path."""
    if len(self._segments) <= 1:
      return None
    return _BranchPath(self._segments[:-1])

  def is_descendant_of(self, ancestor: _BranchPath) -> bool:
    """Checks if this path is a descendant of the ancestor path.

    A path is a descendant if it starts with all segments of the ancestor path
    and has additional segments.
    """
    if len(self._segments) <= len(ancestor._segments):
      return False
    return self._segments[: len(ancestor._segments)] == ancestor._segments

  @staticmethod
  def common_prefix(paths: list[_BranchPath]) -> _BranchPath:
    """Finds the common prefix of a list of _BranchPath objects."""
    if not paths:
      return _BranchPath([])

    common_segments = []
    for segments in zip(*[p.segments for p in paths]):
      if len(set(segments)) == 1:
        common_segments.append(segments[0])
      else:
        break
    return _BranchPath(common_segments)

  def append(
      self,
      segment_or_path: str | _BranchPath,
      run_id: str | None = None,
  ) -> _BranchPath:
    """Returns a new _BranchPath with segment(s) appended.

    Args:
      segment_or_path: A segment name (str), dot-separated path (str), or another
        _BranchPath instance to append.
      run_id: Optional run ID (or function_call_id) to format segment as
        'name@run_id'.
    """
    if isinstance(segment_or_path, _BranchPath):
      if run_id is not None:
        raise ValueError(
            "run_id cannot be provided when segment_or_path is a _BranchPath"
            " instance."
        )
      return _BranchPath(self._segments + segment_or_path.segments)

    if run_id is not None:
      if "." in segment_or_path:
        raise ValueError(
            "run_id cannot be provided when segment_or_path is a dot-separated"
            " path."
        )
      segment = f"{segment_or_path}@{run_id}"
      return _BranchPath(self._segments + [segment])

    new_segments = [s for s in segment_or_path.split(".") if s]
    return _BranchPath(self._segments + new_segments)

  @classmethod
  def is_tool_branch(
      cls, branch: str, node_name: str, tool_call_ids: set[str]
  ) -> bool:
    """Whether ``branch`` is the sub-branch a tool message is published on.

    A tool's user-facing message is published on ``<tool>@<function_call_id>``
    while being authored under the agent's name and carrying the agent's node
    path, so the branch is the only thing that identifies it; a function call id
    in the leaf segment distinguishes it from an ordinary node branch, whose
    leaf carries a run id instead.

    A function call id in the leaf is not sufficient on its own: an agent run as
    a tool is scoped on ``<parent>.<agent name>@<function call id>``, which is
    that agent's own branch. A leaf naming the node itself is therefore never
    treated as a tool branch.

    Args:
      branch: The branch to classify.
      node_name: Name of the node the branch is being considered for.
      tool_call_ids: Ids of the function calls recorded in the session.

    Returns:
      True if the branch belongs to a tool message rather than to the node.
    """
    segments = cls.from_string(branch).segments
    if not segments:
      return False
    leaf_name, separator, trailing_id = segments[-1].rpartition("@")
    if not separator or trailing_id not in tool_call_ids:
      return False
    return leaf_name != node_name

  @staticmethod
  def is_same_or_below(path: str, ancestor: str) -> bool:
    """Whether ``path`` is ``ancestor`` or lies below it.

    The string-level form of ``path == ancestor or
    from_string(path).is_descendant_of(from_string(ancestor))``. Both
    arguments must be non-empty.

    Args:
      path: The branch to classify.
      ancestor: The branch it is compared against.

    Returns:
      True if path names the same branch as ancestor, or one below it.
    """
    return path == ancestor or (
        path.startswith(ancestor) and path[len(ancestor)] == "."
    )

  @staticmethod
  def has_tool_segment_below(
      path: str | None,
      base: str | None,
      node_name: str,
      tool_call_ids: set[str],
  ) -> bool:
    """Whether any segment of ``path`` strictly below ``base`` is a tool branch.

    The string-level form of testing ``is_tool_branch`` on every segment of
    ``path`` below ``base``. Every segment is checked, not only the leaf,
    because a workflow run by a tool fans out further below the tool's own
    segment.

    Args:
      path: The branch to walk.
      base: The branch the walk starts below, empty to walk all of path.
      node_name: Name of the node the branch is being considered for.
      tool_call_ids: Ids of the function calls recorded in the session.

    Returns:
      True if path lies strictly below base and a segment in between belongs
      to a tool message rather than to the node.
    """
    if not path or not tool_call_ids:
      return False
    if base:
      if not (
          len(path) > len(base)
          and path.startswith(base)
          and path[len(base)] == "."
      ):
        return False
      sub_path = path[len(base) + 1 :]
    else:
      sub_path = path
    for segment in sub_path.split("."):
      leaf_name, separator, trailing_id = segment.rpartition("@")
      if separator and trailing_id in tool_call_ids and leaf_name != node_name:
        return True
    return False

  @classmethod
  def create_sub_branch(
      cls,
      base_branch: str | None,
      *,
      name: str,
      run_id: str | None = None,
  ) -> str:
    """Creates a new dot-separated branch path string by appending a segment.

    Example:
      _BranchPath.create_sub_branch('parent', name='child', run_id='1') ->
      'parent.child@1'
      _BranchPath.create_sub_branch(None, name='agent') -> 'agent'
    """
    return str(cls.from_string(base_branch).append(name, run_id=run_id))
