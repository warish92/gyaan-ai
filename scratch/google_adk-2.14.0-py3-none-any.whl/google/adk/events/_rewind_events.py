# Copyright 2026 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Helpers for resolving which events are live after rewinds."""

from __future__ import annotations

from .event import Event


def get_active_events(events: list[Event]) -> list[Event]:
  """Returns the chronological subset of events that survive all rewinds."""
  return _apply_rewinds(events)


def _apply_rewinds(events: list[Event]) -> list[Event]:
  """Returns ``events`` with rewound invocations removed.

  Iterates backward. When an event carries
  ``actions.rewind_before_invocation_id == X``, drops that event together with
  every event between it and the earliest event of invocation ``X`` (inclusive),
  then resumes the backward walk from there.

  This is the single source of truth for "which events are live" after rewinds.
  Both LLM prompt building (``google.adk.flows.llm_flows.contents``) and context
  compaction (``google.adk.apps.compaction``) must agree on it, otherwise
  rewound content can leak back into prompts through a compaction summary.

  Args:
    events: The full event history, in chronological order.

  Returns:
    The chronological subset of ``events`` that survives all rewinds.
  """
  # Fast path: a history with no rewind is already live; skip the backward
  # walk.
  if not any(
      e.actions and e.actions.rewind_before_invocation_id for e in events
  ):
    return list(events)

  first_idx_by_inv: dict[str, int] | None = None
  kept: list[Event] = []
  i = len(events) - 1
  while i >= 0:
    event = events[i]
    if event.actions and event.actions.rewind_before_invocation_id:
      if first_idx_by_inv is None:
        first_idx_by_inv = {}
        for idx, ev in enumerate(events):
          if ev.invocation_id and ev.invocation_id not in first_idx_by_inv:
            first_idx_by_inv[ev.invocation_id] = idx
      rewind_idx = first_idx_by_inv.get(
          event.actions.rewind_before_invocation_id
      )
      if rewind_idx is not None and rewind_idx < i:
        i = rewind_idx
    else:
      kept.append(event)
    i -= 1
  kept.reverse()
  return kept
