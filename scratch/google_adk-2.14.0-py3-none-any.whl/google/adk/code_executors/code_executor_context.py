# Copyright 2026 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

"""The persistent context used to configure the code executor."""

import copy
import dataclasses
import datetime
from typing import Any
from typing import cast
from typing import TYPE_CHECKING
from typing import TypeAlias

from .code_execution_utils import File

if TYPE_CHECKING:
  from ..sessions.state import State

_CONTEXT_KEY = '_code_execution_context'
_SESSION_ID_KEY = 'execution_session_id'
_PROCESSED_FILE_NAMES_KEY = 'processed_input_files'
_INPUT_FILE_KEY = '_code_executor_input_files'
_ERROR_COUNT_KEY = '_code_executor_error_counts'

_CODE_EXECUTION_RESULTS_KEY = '_code_execution_results'

_SessionState: TypeAlias = 'State | dict[str, Any]'


class CodeExecutorContext:
  """The persistent context used to configure the code executor."""

  _context: dict[str, Any]

  def __init__(self, session_state: _SessionState) -> None:
    """Initializes the code executor context.

    Args:
      session_state: The session state to get the code executor context from.
    """
    self._context = self._get_code_executor_context(session_state)
    self._session_state = session_state

  def get_state_delta(self) -> dict[str, Any]:
    """Gets the state delta to update in the persistent session state.

    Returns:
      The state delta to update in the persistent session state.
    """
    context_to_update = copy.deepcopy(self._context)
    return {_CONTEXT_KEY: context_to_update}

  def get_execution_id(self) -> str | None:
    """Gets the session ID for the code executor.

    Returns:
      The session ID for the code executor context.
    """
    return cast(str | None, self._context.get(_SESSION_ID_KEY))

  def set_execution_id(self, session_id: str) -> None:
    """Sets the session ID for the code executor.

    Args:
      session_id: The session ID for the code executor.
    """
    self._context[_SESSION_ID_KEY] = session_id

  def get_processed_file_names(self) -> list[str]:
    """Gets the processed file names from the session state.

    Returns:
      A list of processed file names in the code executor context.
    """
    file_names = self._context.get(_PROCESSED_FILE_NAMES_KEY)
    if file_names is None:
      return []
    return cast(list[str], file_names)

  def add_processed_file_names(self, file_names: list[str]) -> None:
    """Adds the processed file name to the session state.

    Args:
      file_names: The processed file names to add to the session state.
    """
    processed_file_names = self.get_processed_file_names()
    processed_file_names.extend(file_names)
    self._context[_PROCESSED_FILE_NAMES_KEY] = processed_file_names

  def get_input_files(self) -> list[File]:
    """Gets the code executor input file names from the session state.

    Returns:
      A list of input files in the code executor context.
    """
    stored_files = self._session_state.get(_INPUT_FILE_KEY)
    if stored_files is None:
      return []
    return [File(**file) for file in cast(list[dict[str, Any]], stored_files)]

  def add_input_files(
      self,
      input_files: list[File],
  ) -> None:
    """Adds the input files to the code executor context.

    Args:
      input_files: The input files to add to the code executor context.
    """
    stored_files = cast(
        list[dict[str, Any]], self._session_state.get(_INPUT_FILE_KEY, [])
    )
    for input_file in input_files:
      stored_files.append(dataclasses.asdict(input_file))
    self._session_state[_INPUT_FILE_KEY] = stored_files

  def clear_input_files(self) -> None:
    """Removes the input files and processed file names to the code executor context."""
    if _INPUT_FILE_KEY in self._session_state:
      self._session_state[_INPUT_FILE_KEY] = []
    if _PROCESSED_FILE_NAMES_KEY in self._context:
      self._context[_PROCESSED_FILE_NAMES_KEY] = []

  def get_error_count(self, invocation_id: str) -> int:
    """Gets the error count from the session state.

    Args:
      invocation_id: The invocation ID to get the error count for.

    Returns:
      The error count for the given invocation ID.
    """
    error_counts = cast(
        dict[str, int] | None, self._session_state.get(_ERROR_COUNT_KEY)
    )
    if error_counts is None:
      return 0
    return error_counts.get(invocation_id, 0)

  def increment_error_count(self, invocation_id: str) -> None:
    """Increments the error count from the session state.

    Args:
      invocation_id: The invocation ID to increment the error count for.
    """
    stored_counts = cast(
        dict[str, int], self._session_state.get(_ERROR_COUNT_KEY, {})
    )
    stored_counts[invocation_id] = self.get_error_count(invocation_id) + 1
    self._session_state[_ERROR_COUNT_KEY] = stored_counts

  def reset_error_count(self, invocation_id: str) -> None:
    """Resets the error count from the session state.

    Args:
      invocation_id: The invocation ID to reset the error count for.
    """
    stored_counts = cast(
        dict[str, int] | None, self._session_state.get(_ERROR_COUNT_KEY)
    )
    if stored_counts is None:
      return
    stored_counts.pop(invocation_id, None)
    self._session_state[_ERROR_COUNT_KEY] = stored_counts

  def update_code_execution_result(
      self,
      invocation_id: str,
      code: str,
      result_stdout: str,
      result_stderr: str,
  ) -> None:
    """Updates the code execution result.

    Args:
      invocation_id: The invocation ID to update the code execution result for.
      code: The code to execute.
      result_stdout: The standard output of the code execution.
      result_stderr: The standard error of the code execution.
    """
    stored_results = cast(
        dict[str, list[dict[str, Any]]],
        self._session_state.get(_CODE_EXECUTION_RESULTS_KEY, {}),
    )
    invocation_results = stored_results.get(invocation_id, [])
    invocation_results.append({
        'code': code,
        'result_stdout': result_stdout,
        'result_stderr': result_stderr,
        'timestamp': int(datetime.datetime.now().timestamp()),
    })
    stored_results[invocation_id] = invocation_results
    self._session_state[_CODE_EXECUTION_RESULTS_KEY] = stored_results

  def _get_code_executor_context(
      self, session_state: _SessionState
  ) -> dict[str, Any]:
    """Gets the code executor context from the session state.

    Args:
      session_state: The session state to get the code executor context from.

    Returns:
      A dict of code executor context.
    """
    if _CONTEXT_KEY not in session_state:
      session_state[_CONTEXT_KEY] = {}
    return cast(dict[str, Any], session_state[_CONTEXT_KEY])
