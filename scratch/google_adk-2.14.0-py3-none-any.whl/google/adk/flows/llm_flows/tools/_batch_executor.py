# Copyright 2026 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Batch execution, parallel dispatch, and event merging for tool calls."""

from __future__ import annotations

import asyncio
from collections.abc import Callable
from collections.abc import Coroutine
import logging
from typing import Any
from typing import TYPE_CHECKING
from typing import TypeVar

from google.genai import types

from ....agents.llm.task._finish_task_tool import FINISH_TASK_TOOL_NAME
from ....events.event import Event
from ....events.event_actions import EventActions
from ....telemetry.tracing import trace_merged_tool_calls
from ....telemetry.tracing import tracer
from ....tools.base_tool import BaseTool
from ....tools.tool_confirmation import ToolConfirmation
from ....workflow._errors import NodeInterruptedError
from ..core._utils import as_llm_agent as _as_llm_agent
from ._caller import _execute_single_prepared_call_async
from ._caller import _prepare_single
from ._caller import _PreparedFunctionCall

if TYPE_CHECKING:
  from ....agents.invocation_context import InvocationContext
  from ....agents.llm_agent import LlmAgent

logger = logging.getLogger('google_adk.' + __name__)

_T = TypeVar('_T')


def deep_merge_dicts(d1: dict[str, Any], d2: dict[str, Any]) -> dict[str, Any]:
  """Recursively merges d2 into d1."""
  for key, value in d2.items():
    if key in d1 and isinstance(d1[key], dict) and isinstance(value, dict):
      d1[key] = deep_merge_dicts(d1[key], value)
    else:
      d1[key] = value
  return d1


def merge_parallel_function_response_events(
    function_response_events: list[Event],
) -> Event:
  """Merges parallel function response events into a single response event."""
  if not function_response_events:
    raise ValueError('No function response events provided.')

  if len(function_response_events) == 1:
    return function_response_events[0]
  merged_parts = []
  for event in function_response_events:
    if event.content:
      for part in event.content.parts or []:
        merged_parts.append(part)

  # Use the first event as the "base" for common attributes
  base_event = function_response_events[0]

  # Merge actions from all events
  merged_actions_data: dict[str, Any] = {}
  aggregated_ui_widgets = []
  for event in function_response_events:
    if event.actions:
      # Use `by_alias=True` because it converts the model to a dictionary
      # while respecting field aliases, ensuring that the enum fields are
      # correctly handled without creating a duplicate.
      actions_dict = event.actions.model_dump(exclude_none=True, by_alias=True)
      ui_widgets = actions_dict.pop(
          'renderUiWidgets', None
      ) or actions_dict.pop('render_ui_widgets', None)
      if ui_widgets:
        aggregated_ui_widgets.extend(ui_widgets)

      merged_actions_data = deep_merge_dicts(
          merged_actions_data,
          actions_dict,
      )

  if aggregated_ui_widgets:
    merged_actions_data['renderUiWidgets'] = aggregated_ui_widgets

  merged_actions = EventActions.model_validate(merged_actions_data)

  # Create the new merged event
  merged_event = Event(
      invocation_id=base_event.invocation_id,
      author=base_event.author,
      branch=base_event.branch,
      content=types.Content(role='user', parts=merged_parts),
      actions=merged_actions,
      live_session_id=base_event.live_session_id,
  )

  # Use the base_event as the timestamp
  merged_event.timestamp = base_event.timestamp
  return merged_event


def _apply_latest_state_writes(
    merged_event: Event,
    function_response_events: list[Event],
    session_state: dict[str, Any],
) -> None:
  """Re-applies the latest value of list and dict keys several calls wrote.

  Calls share the session state, so a call that reads a key after another call
  wrote it builds on that write, which merging in call order alone can drop.
  """
  merged_delta = merged_event.actions.state_delta
  latest_writes: dict[str, Any] = {}
  for key in merged_delta:
    latest = session_state.get(key)
    if not isinstance(latest, (dict, list)):
      continue
    writes = [
        event.actions.state_delta[key]
        for event in function_response_events
        if key in event.actions.state_delta
    ]
    # State stores the same object in the session and in the call's delta.
    if len(writes) > 1 and any(write is latest for write in writes):
      latest_writes[key] = latest
  deep_merge_dicts(merged_delta, latest_writes)


def _merge_and_trace_function_response_events(
    invocation_context: InvocationContext,
    function_response_events: list[Event],
) -> Event:
  """Merges the response events of parallel calls into a single event."""
  merged_event = merge_parallel_function_response_events(
      function_response_events
  )
  _apply_latest_state_writes(
      merged_event, function_response_events, invocation_context.session.state
  )

  # this is needed for debug traces of parallel calls
  # individual response with tool.name is traced in __build_response_event
  # (we drop tool.name from span name here as this is merged event)
  if len(function_response_events) > 1:
    with tracer.start_as_current_span('execute_tool (merged)'):
      trace_merged_tool_calls(
          response_event_id=merged_event.id,
          function_response_event=merged_event,
          invocation_context=invocation_context,
      )
  return merged_event


def _start_execute_task(
    prepared_call: _PreparedFunctionCall,
    coro: Coroutine[Any, Any, _T],
) -> asyncio.Task[_T]:
  """Starts the execute phase of one call in the context its prepare left behind.

  asyncio hands every new task a copy of the context that was current when the
  task was created, and whatever the task sets stays in that copy. The prepare
  phase runs in a task of its own, so a contextvar a before-tool callback sets
  there -- an auth token, a tracing span -- is not set in an execute task
  created by the caller. Creating that task from inside the prepare phase's
  snapshot gives it a copy of the snapshot instead, so the tool sees what the
  callbacks set. Copying rather than sharing also keeps each call to itself:
  what the tool sets reaches neither its sibling calls nor the caller.
  """
  return prepared_call.contextvars_snapshot.run(asyncio.create_task, coro)


def _cancel_unfinished_tasks(tasks: list[asyncio.Task[Any]]) -> None:
  """Cancels tasks that are still running and not already cancelling."""
  for t in tasks:
    if not t.done() and not t.cancelling():
      t.cancel()


async def _gather_or_cancel(tasks: list[asyncio.Task[_T]]) -> list[_T]:
  """Awaits every task; cancels and awaits the rest if one fails or the caller is cancelled or closed."""
  gatherer = asyncio.gather(*tasks)
  try:
    return list(await gatherer)
  except GeneratorExit:
    gatherer.cancel()
    # Retrieve the exception so the abandoned gather future does not log
    # "Future exception was never retrieved" at GC.
    gatherer.add_done_callback(
        lambda fut: fut.exception() if not fut.cancelled() else None
    )
    raise
  except BaseException:
    _cancel_unfinished_tasks(tasks)
    await asyncio.gather(*tasks, return_exceptions=True)
    raise


async def _prepare_function_calls(
    invocation_context: InvocationContext,
    function_calls: list[types.FunctionCall],
    tools_dict: dict[str, BaseTool],
    agent: LlmAgent,
    *,
    filters: set[str] | None = None,
    tool_confirmation_dict: dict[str, ToolConfirmation] | None = None,
) -> list[_PreparedFunctionCall]:
  """Prepares every call that the execute phase will run, in parallel."""
  filtered_calls = [
      fc for fc in function_calls if not filters or fc.id in filters
  ]

  if not filtered_calls:
    return []

  tasks = [
      asyncio.create_task(
          _prepare_single(
              invocation_context,
              function_call,
              tools_dict,
              agent,
              tool_confirmation_dict.get(function_call.id)
              if tool_confirmation_dict and function_call.id is not None
              else None,
          )
      )
      for function_call in filtered_calls
  ]
  return await _gather_or_cancel(tasks)


_KEPT_FUNCTION_RESPONSE_EVENT_ATTR = '_adk_kept_function_response_event'


async def _execute_prepared_function_calls(
    invocation_context: InvocationContext,
    prepared_calls: list[_PreparedFunctionCall],
    *,
    call_executor: Callable[
        [_PreparedFunctionCall], Coroutine[Any, Any, Event | None]
    ],
    live_session_id: str | None = None,
) -> Event | None:
  """Runs prepared calls in parallel and merges their response events."""
  if not prepared_calls:
    return None

  # Create tasks for parallel execution
  tasks = [
      _start_execute_task(prepared_call, call_executor(prepared_call))
      for prepared_call in prepared_calls
  ]

  # Wait for all tasks to complete
  try:
    maybe_function_response_events = await _gather_or_cancel(tasks)
  except (Exception, NodeInterruptedError) as e:
    # A call raised and its unfinished siblings were cancelled. Calls that had
    # already finished may have had side effects, so keep their real results
    # for the postprocessor to yield before the error unwinds the agent.
    if (
        kept_event := _keep_completed_responses(invocation_context, tasks)
    ) is not None:
      setattr(e, _KEPT_FUNCTION_RESPONSE_EVENT_ATTR, kept_event)
    raise

  # Filter out None results
  function_response_events = [
      event for event in maybe_function_response_events if event is not None
  ]

  if live_session_id is not None:
    for event in function_response_events:
      event.live_session_id = live_session_id

  if not function_response_events:
    return None

  return _merge_and_trace_function_response_events(
      invocation_context, function_response_events
  )


def _keep_completed_responses(
    invocation_context: InvocationContext,
    tasks: list[asyncio.Task[Event | None]],
) -> Event | None:
  """Keeps the responses of calls that finished before their batch ended early.

  Only plain tool results are kept: a call that was cancelled, raised or
  returned no event gets nothing. They are merged as a complete batch would
  be and returned for the flow postprocessor to yield before re-raising. Live
  mode and aborted invocations are skipped.
  """
  if (
      invocation_context.live_request_queue is not None
      or invocation_context.is_aborted
  ):
    return None
  finished = [
      t.result()
      for t in tasks
      if t.done() and not t.cancelled() and t.exception() is None
  ]
  completed = [
      event
      for event in finished
      if event is not None and _is_plain_result(event)
  ]
  if not completed:
    return None
  return _merge_and_trace_function_response_events(
      invocation_context, completed
  )


def _pop_kept_function_response_event(
    error: BaseException,
) -> Event | None:
  """Pops and returns any kept function response event attached to `error`."""
  kept_event = getattr(error, _KEPT_FUNCTION_RESPONSE_EVENT_ATTR, None)
  if isinstance(kept_event, Event):
    delattr(error, _KEPT_FUNCTION_RESPONSE_EVENT_ATTR)
    return kept_event
  return None


def _is_plain_result(event: Event) -> bool:
  """True if the event is a tool result with no control-flow actions.

  Besides the tool's state and artifact deltas, any action (a transfer, an
  escalation, a confirmation or credential request whose tool has not run)
  is an instruction the failed step never carried out, so it is not kept.
  finish_task sets no action and is detected by name.
  """
  actions = event.actions.model_copy(
      update={
          'state_delta': {},
          'artifact_delta': {},
          'skip_summarization': None,
          'render_ui_widgets': None,
      }
  )
  if actions != EventActions():
    return False
  return not any(
      response.name == FINISH_TASK_TOOL_NAME
      for response in event.get_function_responses()
  )


async def _execute_prepared_function_calls_async(
    invocation_context: InvocationContext,
    prepared_calls: list[_PreparedFunctionCall],
    agent: LlmAgent,
) -> Event | None:
  """Runs the prepared calls in parallel and merges their response events."""
  return await _execute_prepared_function_calls(
      invocation_context,
      prepared_calls,
      call_executor=lambda prepared_call: _execute_single_prepared_call_async(
          invocation_context, prepared_call, agent
      ),
  )


async def handle_function_call_list_async(
    invocation_context: InvocationContext,
    function_calls: list[types.FunctionCall],
    tools_dict: dict[str, BaseTool],
    filters: set[str] | None = None,
    tool_confirmation_dict: dict[str, ToolConfirmation] | None = None,
) -> Event | None:
  """Calls the functions and returns the function response event."""
  agent = _as_llm_agent(invocation_context)
  prepared_calls = await _prepare_function_calls(
      invocation_context,
      function_calls,
      tools_dict,
      agent,
      filters=filters,
      tool_confirmation_dict=tool_confirmation_dict,
  )
  return await _execute_prepared_function_calls_async(
      invocation_context, prepared_calls, agent
  )


async def handle_function_calls_live(
    invocation_context: InvocationContext,
    function_call_event: Event,
    tools_dict: dict[str, BaseTool],
) -> Event | None:
  """Calls the functions and returns the function response event."""
  from . import _live_caller

  return await _live_caller.handle_function_calls_live(
      invocation_context=invocation_context,
      function_call_event=function_call_event,
      tools_dict=tools_dict,
  )
