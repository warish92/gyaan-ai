# Copyright 2026 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from fastapi.openapi.models import OAuthFlows
from fastapi.openapi.models import SecurityBase
from pydantic import ValidationError

from .auth_credential import AuthCredential
from .auth_credential import AuthCredentialTypes
from .auth_credential import HttpAuth
from .auth_credential import HttpCredentials
from .auth_credential import OAuth2Auth
from .auth_schemes import AuthSchemeType
from .auth_schemes import OpenIdConnectWithConfig
from .auth_tool import AuthConfig
from .exchanger.oauth2_credential_exchanger import OAuth2CredentialExchanger
from .oauth2_credential_util import _credential_without_client_secret
from .oauth2_credential_util import _with_configured_client

if TYPE_CHECKING:
  from ..sessions.state import State
  from .auth_schemes import AuthScheme
try:
  from authlib.common.security import generate_token
  from authlib.integrations.requests_client import OAuth2Session

  AUTHLIB_AVAILABLE = True
except ImportError:
  AUTHLIB_AVAILABLE = False

logger = logging.getLogger("google_adk." + __name__)


def _normalize_oauth_scopes(
    scopes: dict[str, str] | list[str] | None,
) -> list[str]:
  """Normalize OAuth scopes into the list shape expected by authlib."""
  if not scopes:
    return []
  if isinstance(scopes, dict):
    return list(scopes.keys())
  return list(scopes)


def _credential_from_string(
    val: str,
    auth_scheme: AuthScheme | None = None,
) -> AuthCredential:
  """Builds an AuthCredential from a raw token or key string per auth_scheme."""
  if not val:
    raise ValueError("Credential string cannot be empty.")

  if not auth_scheme:
    return AuthCredential(
        auth_type=AuthCredentialTypes.OAUTH2,
        oauth2=OAuth2Auth(access_token=val),
    )

  scheme_type = auth_scheme.type_
  if scheme_type == AuthSchemeType.apiKey:
    return AuthCredential(
        auth_type=AuthCredentialTypes.API_KEY,
        api_key=val,
    )
  if scheme_type == AuthSchemeType.http:
    scheme = getattr(auth_scheme, "scheme", "bearer")
    if scheme.lower() == "basic":
      raise ValueError(
          "HTTP basic authentication requires username and password"
          " credentials, not a raw token string."
      )
    return AuthCredential(
        auth_type=AuthCredentialTypes.HTTP,
        http=HttpAuth(
            scheme=scheme,
            credentials=HttpCredentials(token=val),
        ),
    )
  return AuthCredential(
      auth_type=AuthCredentialTypes.OAUTH2,
      oauth2=OAuth2Auth(access_token=val),
  )


def _credential_without_configured_secrets(
    credential: AuthCredential | None,
) -> AuthCredential | None:
  """Returns a copy of credential with every agent-supplied secret removed."""
  redacted = _credential_without_client_secret(credential)
  if redacted is None:
    return None
  redacted.api_key = None
  if redacted.http is not None:
    redacted.http.credentials.password = None
    redacted.http.credentials.token = None
    redacted.http.additional_headers = None
  return redacted


def _without_configured_secrets(auth_config: AuthConfig) -> AuthConfig:
  """Returns a copy of auth_config carrying no secret the agent configured.

  The auth request travels to, and is echoed back by, the client, and is
  persisted in the session. An API key, an HTTP password or token, and an
  OAuth2 client secret all belong to the agent rather than to the end user,
  so none of them are sent. The tool's own configuration still holds them when
  the credential is finally prepared.
  """
  redacted = auth_config.model_copy(deep=True)
  redacted.raw_auth_credential = _credential_without_configured_secrets(
      redacted.raw_auth_credential
  )
  redacted.exchanged_auth_credential = _credential_without_configured_secrets(
      redacted.exchanged_auth_credential
  )
  return redacted


class AuthHandler:
  """A handler that handles the auth flow in Agent Development Kit to help
  orchestrate the credential request and response flow (e.g. OAuth flow)
  This class should only be used by Agent Development Kit.
  """

  def __init__(self, auth_config: AuthConfig):
    self.auth_config = auth_config

  async def exchange_auth_token(
      self,
  ) -> AuthCredential:
    exchanger = OAuth2CredentialExchanger()
    exchange_result = await exchanger.exchange(
        self.auth_config.exchanged_auth_credential, self.auth_config.auth_scheme
    )
    return exchange_result.credential

  async def parse_and_store_auth_response(self, state: State) -> None:
    credential_key = self.auth_config.credential_key
    if not credential_key:
      raise ValueError("credential_key is empty.")

    temp_credential_key = "temp:" + credential_key

    self.auth_config.exchanged_auth_credential = _with_configured_client(
        credential=self.auth_config.exchanged_auth_credential,
        raw_credential=self.auth_config.raw_auth_credential,
    )
    credential = self.auth_config.exchanged_auth_credential
    if self._is_exchangeable(credential):
      credential = await self.exchange_auth_token()

    # Session state is readable by the client, so the secret does not go in it.
    state[temp_credential_key] = _credential_without_client_secret(credential)

  def _validate(self) -> None:
    if not self.auth_config.auth_scheme:
      raise ValueError("auth_scheme is empty.")

  def _is_exchangeable(
      self,
      credential: AuthCredential | None,
      *,
      allow_public: bool = False,
  ) -> bool:
    """Returns whether credential still needs, and can do, a token exchange."""
    if not isinstance(
        self.auth_config.auth_scheme, SecurityBase
    ) or self.auth_config.auth_scheme.type_ not in (
        AuthSchemeType.oauth2,
        AuthSchemeType.openIdConnect,
    ):
      return False
    oauth2 = credential.oauth2 if credential else None
    if not oauth2 or oauth2.access_token or not oauth2.client_id:
      return False
    return bool(oauth2.client_secret or allow_public)

  def _read_stored_credential(
      self, state: State
  ) -> tuple[str, AuthCredential] | None:
    """Returns the state key and credential stored for this auth config."""
    credential_key = self.auth_config.credential_key
    if not credential_key:
      return None

    # The temp credential key is the standard ADK flow; the key without the
    # 'temp:' prefix is the fallback.
    for key in ("temp:" + credential_key, credential_key):
      val = state.get(key, None)
      if isinstance(val, AuthCredential):
        return key, val
      try:
        if isinstance(val, dict):
          return key, AuthCredential.model_validate(val)
        if isinstance(val, str) and val:
          return key, _credential_from_string(val, self.auth_config.auth_scheme)
      except (ValidationError, ValueError):
        logger.warning(
            "Ignoring malformed credential stored under state key %r.", key
        )
        continue

    return None

  def has_auth_response(self, state: State) -> bool:
    """Returns whether an auth response is stored, without exchanging it."""
    return self._read_stored_credential(state) is not None

  def get_auth_response(self, state: State) -> AuthCredential | None:
    """Returns the stored auth response, exchanging it for a token if needed.

    The stored response carries no client secret, since the auth request went
    through the client. The secret configured on this handler's auth config is
    re-attached here so the exchange can happen without ever trusting the
    client's copy, and is dropped again from what goes back into the session.

    The token request blocks the calling thread. Callers that can await should
    let `CredentialManager` do the exchange instead.
    """
    stored = self._read_stored_credential(state)
    if stored is None:
      return None

    key, credential = stored
    credential = _with_configured_client(
        credential=credential,
        raw_credential=self.auth_config.raw_auth_credential,
    )
    if not self._is_exchangeable(credential, allow_public=True):
      return credential

    exchange_result = OAuth2CredentialExchanger()._exchange_sync(
        credential, self.auth_config.auth_scheme
    )
    state[key] = _credential_without_client_secret(exchange_result.credential)
    return exchange_result.credential

  def generate_auth_request(self) -> AuthConfig:
    return _without_configured_secrets(self._generate_auth_request())

  def _generate_auth_request(self) -> AuthConfig:
    if not isinstance(
        self.auth_config.auth_scheme, SecurityBase
    ) or self.auth_config.auth_scheme.type_ not in (
        AuthSchemeType.oauth2,
        AuthSchemeType.openIdConnect,
    ):
      return self.auth_config.model_copy(deep=True)

    # auth_uri already in exchanged credential
    if (
        self.auth_config.exchanged_auth_credential
        and self.auth_config.exchanged_auth_credential.oauth2
        and self.auth_config.exchanged_auth_credential.oauth2.auth_uri
    ):
      return self.auth_config.model_copy(deep=True)

    # Check if raw_auth_credential exists
    if not self.auth_config.raw_auth_credential:
      raise ValueError(
          f"Auth Scheme {self.auth_config.auth_scheme.type_} requires"
          " auth_credential."
      )

    # Check if oauth2 exists in raw_auth_credential
    if not self.auth_config.raw_auth_credential.oauth2:
      raise ValueError(
          f"Auth Scheme {self.auth_config.auth_scheme.type_} requires oauth2 in"
          " auth_credential."
      )

    # auth_uri in raw credential
    if self.auth_config.raw_auth_credential.oauth2.auth_uri:
      return AuthConfig(
          auth_scheme=self.auth_config.auth_scheme,
          raw_auth_credential=self.auth_config.raw_auth_credential,
          exchanged_auth_credential=self.auth_config.raw_auth_credential.model_copy(
              deep=True
          ),
          credential_key=self.auth_config.credential_key,
      )

    # Public clients (Azure AD B2C, PKCE) have a client_id and no secret.
    if not self.auth_config.raw_auth_credential.oauth2.client_id:
      raise ValueError(
          f"Auth Scheme {self.auth_config.auth_scheme.type_} requires"
          " client_id in auth_credential.oauth2."
      )

    # Generate new auth URI
    exchanged_credential = self.generate_auth_uri()
    return AuthConfig(
        auth_scheme=self.auth_config.auth_scheme,
        raw_auth_credential=self.auth_config.raw_auth_credential,
        exchanged_auth_credential=exchanged_credential,
        credential_key=self.auth_config.credential_key,
    )

  def generate_auth_uri(
      self,
  ) -> AuthCredential | None:
    """Generates a response containing the auth uri for user to sign in.

    Returns:
        An AuthCredential object containing the auth URI and state, or None if
        authlib is unavailable and no raw credential was configured.

    Raises:
        ValueError: If the raw credential carries no oauth2 section, if the
            auth scheme is not one that carries an authorization endpoint, or
            if the credential asks for a code_challenge_method other than
            S256.
    """
    if not AUTHLIB_AVAILABLE:
      return (
          self.auth_config.raw_auth_credential.model_copy(deep=True)
          if self.auth_config.raw_auth_credential
          else None
      )

    auth_scheme = self.auth_config.auth_scheme
    auth_credential = self.auth_config.raw_auth_credential
    if not auth_credential or not auth_credential.oauth2:
      raise ValueError("raw_auth_credential or oauth2 is empty")

    authorization_endpoint: str | None
    if isinstance(auth_scheme, OpenIdConnectWithConfig):
      authorization_endpoint = auth_scheme.authorization_endpoint
      scopes = _normalize_oauth_scopes(auth_scheme.scopes)
    else:
      # `flows` is declared only on OAuth2, but a CustomAuthScheme subclass may
      # also carry one to join the OAuth2 consent flow, so read it off the
      # scheme rather than requiring an OAuth2 instance. Reaching the raise
      # below used to be an AttributeError inside the expression that follows.
      flows = getattr(auth_scheme, "flows", None)
      if not isinstance(flows, OAuthFlows):
        raise ValueError(
            "Cannot generate an auth uri for auth scheme"
            f" {type(auth_scheme).__name__}: it carries no OAuth2 flows."
        )
      authorization_endpoint = (
          (flows.implicit.authorizationUrl if flows.implicit else None)
          or (
              flows.authorizationCode.authorizationUrl
              if flows.authorizationCode
              else None
          )
          or (
              flows.clientCredentials.tokenUrl
              if flows.clientCredentials
              else None
          )
          or (flows.password.tokenUrl if flows.password else None)
      )
      if not authorization_endpoint:
        raise ValueError(
            "Cannot generate an auth uri for auth scheme"
            f" {type(auth_scheme).__name__}: no flow declares an"
            " authorization endpoint."
        )
      if flows.implicit:
        scopes = _normalize_oauth_scopes(flows.implicit.scopes)
      elif flows.authorizationCode:
        scopes = _normalize_oauth_scopes(flows.authorizationCode.scopes)
      elif flows.clientCredentials:
        scopes = _normalize_oauth_scopes(flows.clientCredentials.scopes)
      elif flows.password:
        scopes = _normalize_oauth_scopes(flows.password.scopes)
      else:
        scopes = []

    code_challenge_method = auth_credential.oauth2.code_challenge_method
    if not auth_credential.oauth2.client_secret and not code_challenge_method:
      logger.warning(
          "OAuth2 client_secret is not set for client_id %s; treating client"
          " as public.",
          auth_credential.oauth2.client_id,
      )
      code_challenge_method = "S256"

    client = OAuth2Session(
        auth_credential.oauth2.client_id,
        auth_credential.oauth2.client_secret,
        scope=" ".join(scopes),
        redirect_uri=auth_credential.oauth2.redirect_uri,
        code_challenge_method=code_challenge_method,
    )
    params = {
        "access_type": "offline",
        "prompt": auth_credential.oauth2.prompt or "consent",
    }
    if auth_credential.oauth2.audience:
      params["audience"] = auth_credential.oauth2.audience
    if auth_credential.oauth2.nonce:
      params["nonce"] = auth_credential.oauth2.nonce

    # If using PKCE with S256, ensure a code_verifier exists.
    # If not provided in the credential, generate a cryptographically secure
    # random token of 48 characters (OAuth2 recommends 43-128 characters).
    code_verifier = auth_credential.oauth2.code_verifier

    if code_challenge_method:
      if code_challenge_method != "S256":
        raise ValueError(
            f"Unsupported code_challenge_method: {code_challenge_method}. Only"
            " 'S256' is supported."
        )
      if not code_verifier:
        code_verifier = generate_token(48)

    uri, state = client.create_authorization_url(
        url=authorization_endpoint, code_verifier=code_verifier, **params
    )

    exchanged_auth_credential = auth_credential.model_copy(deep=True)
    if exchanged_auth_credential.oauth2 is not None:
      exchanged_auth_credential.oauth2.auth_uri = uri
      exchanged_auth_credential.oauth2.state = state
      if code_verifier:
        exchanged_auth_credential.oauth2.code_verifier = code_verifier
        exchanged_auth_credential.oauth2.code_challenge_method = (
            code_challenge_method
        )

    return exchanged_auth_credential
