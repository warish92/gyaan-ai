# Copyright 2026 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Private helper module for multi-agent routing and branch path recovery."""

from __future__ import annotations

import logging
from typing import Any
from typing import TYPE_CHECKING

from ..events._abort_events import _is_abort_event
from ..events._branch_path import _BranchPath
from ..events._interrupts import index_open_interrupts
from ..events._node_path_builder import _NodePathBuilder
from ..events._rewind_events import _apply_rewinds
from ..events.event import Event
from ..flows.llm_flows.core._resume import decide_resume_action
from ..flows.llm_flows.core._resume import ResumeRoute
from ..flows.llm_flows.extensions._agent_transfer import _get_transfer_targets
from ..flows.llm_flows.tools._functions import _collect_function_call_ids
from ..flows.llm_flows.tools._functions import find_matching_function_call
from ..utils._agent_mode import DELEGATED_TASK_MODES

if TYPE_CHECKING:
  from ..agents.base_agent import BaseAgent
  from ..agents.invocation_context import InvocationContext
  from ..apps.app import ResumabilityConfig
  from ..sessions.session import Session
  from ..workflow._base_node import BaseNode

logger = logging.getLogger("google_adk." + __name__)


def _resolve_resumed_agent(
    root_agent: BaseAgent,
    call_event: Event,
    events: list[Event],
) -> BaseAgent | None:
  """Resolves the agent in `root_agent`'s hierarchy that owns `call_event`.

  Consults `index_open_interrupts(events[:-1])` first when the trailing
  `FunctionResponse` answers an open interrupt (including one emitted inside a
  tool sub-branch whose `ancestor_authors` identify the calling agent), falling
  back to `call_event.author` and sub-branch run IDs for regular tool calls.
  """
  open_interrupts = index_open_interrupts(events[:-1])
  function_responses = events[-1].get_function_responses()
  if (
      function_responses
      and function_responses[0].id
      and (interrupt := open_interrupts.get(function_responses[0].id))
      is not None
  ):
    for candidate_author in interrupt.candidate_authors:
      if (resumed_agent := root_agent.find_agent(candidate_author)) is not None:
        return resumed_agent

  if (
      call_event.author
      and (resumed_agent := root_agent.find_agent(call_event.author))
      is not None
  ):
    return resumed_agent
  if not call_event.branch:
    return None
  run_ids = {
      rid
      for rid in _BranchPath.from_string(call_event.branch).run_ids
      if not rid.isdigit()
  }
  if not run_ids:
    return None
  for ev in reversed(events):
    if not ev.author:
      continue
    if any(fc.id in run_ids for fc in ev.get_function_calls() if fc.id):
      if (resumed_agent := root_agent.find_agent(ev.author)) is not None:
        return resumed_agent
  return None


def can_transfer_between_agents(root: Any) -> bool:
  """Reports whether any agent in the tree can transfer to another agent."""
  pending = [root]
  while pending:
    agent = pending.pop()
    sub_agents = getattr(agent, "sub_agents", None)
    if not isinstance(sub_agents, list):
      continue
    if hasattr(agent, "disallow_transfer_to_parent") and _get_transfer_targets(
        agent
    ):
      return True
    pending.extend(sub_agents)
  return False


def is_transferable_across_agent_tree(agent_to_run: BaseAgent) -> bool:
  """Whether the agent to run can transfer to any other agent in the agent tree.

  This typically means all agent_to_run's ancestor can transfer to their
  parent_agent all the way to the root_agent.

  Args:
      agent_to_run: The agent to check for transferability.

  Returns:
      True if the agent can transfer, False otherwise.
  """
  agent: BaseAgent | None = agent_to_run
  while agent:
    if not hasattr(agent, "disallow_transfer_to_parent"):
      # Only agents with transfer capability can transfer.
      return False
    if agent.disallow_transfer_to_parent:
      return False
    agent = agent.parent_agent
  return True


def _resolve_task_delegator(
    agent: BaseAgent, root_agent: BaseAgent
) -> BaseAgent:
  """Maps an agent inside a task delegation to the agent that delegated it."""
  delegator = agent
  current = agent
  while current is not root_agent and current.parent_agent is not None:
    if getattr(current, "mode", None) in DELEGATED_TASK_MODES:
      delegator = current.parent_agent
    current = current.parent_agent
  return delegator


def find_agent_to_run(
    session: Session,
    root_agent: BaseAgent,
    resumability_config: ResumabilityConfig | None = None,
) -> BaseAgent:
  """Finds the agent to run to continue the session.

  A qualified agent must be either of:

  - The agent that returned a function call and the last user message is a
    function response to this function call.
  - The root agent.
  - An LlmAgent who replied last and is capable to transfer to any other agent
    in the agent hierarchy.
  - The target of the latest valid transfer_to_agent, when the target has not
    replied since (e.g. it failed before yielding any event).

  An agent inside a task delegation is replaced by the agent that delegated it.

  Args:
      session: The session to find the agent for.
      root_agent: The agent of the runner.
      resumability_config: Optional resumability configuration.

  Returns:
    The agent to run. (the active agent that should reply to the latest user
    message)
  """
  # Mesh and Workflow Agents handle their own internal routing.
  # Workflow will figure which node is interrupted and should be resumed.
  from ..workflow._workflow import Workflow

  if isinstance(root_agent, Workflow):
    return root_agent

  # If the last event is a function response, should send this response to
  # the agent that returned the corresponding function call regardless the
  # type of the agent. e.g. a remote a2a agent may surface a credential
  # request as a special long-running function tool call.
  filtered_events = _apply_rewinds(session.events)
  last_non_user_event = next(
      (ev for ev in reversed(filtered_events) if ev.author != "user"),
      None,
  )
  event = (
      find_matching_function_call(filtered_events)
      if (
          filtered_events
          and not _is_abort_event(filtered_events[-1])
          and not (
              last_non_user_event is not None
              and _is_abort_event(last_non_user_event)
          )
      )
      else None
  )
  is_resumable = bool(resumability_config and resumability_config.is_resumable)
  if event and event.author:
    answer_event = filtered_events[-1]
    route = decide_resume_action(
        event,
        answer_event,
        is_resumable=is_resumable,
    )
    if route in (ResumeRoute.ROUTE_TO_AUTHOR, ResumeRoute.REPLAY_CALLS):
      # `_resolve_resumed_agent` returns None when the author does not
      # correspond to any agent in the current hierarchy (e.g. the author is
      # "user" or a stale or foreign agent name carried over from a previous
      # turn/session). Fall through to the event-scan logic below (which
      # ultimately falls back to the root agent) whenever the author cannot be
      # resolved.
      if (
          resumed_agent := _resolve_resumed_agent(
              root_agent, event, filtered_events
          )
      ) is not None:
        return _resolve_task_delegator(resumed_agent, root_agent)

  def _event_filter(event: Event) -> bool:
    """Filters out user, abort-sealing and agent state change events."""
    if event.author == "user" or _is_abort_event(event):
      return False
    if event.actions.agent_state is not None or event.actions.end_of_agent:
      return False
    # A node failure is recorded as an error event without content. It is not
    # a reply, and its author may be inherited from the parent context, so it
    # must not decide which agent owns the conversation.
    if event.error_code and not (event.content and event.content.parts):
      return False
    return True

  for event in filter(_event_filter, reversed(filtered_events)):
    # The target of an unanswered transfer owns the turn. Resolving it among
    # the author's transfer targets leaves transfers the scheduler rejected
    # out of routing.
    if (target_name := event.actions.transfer_to_agent) and (
        source := root_agent.find_agent(event.author)
    ):
      target = next(
          (a for a in _get_transfer_targets(source) if a.name == target_name),
          None,
      )
      if target is not None and is_transferable_across_agent_tree(target):
        return target
    if event.author == root_agent.name:
      # Found root agent.
      return root_agent
    if not (agent := root_agent.find_sub_agent(event.author)):
      # Agent not found, continue looking.
      logger.warning(
          "Event from an unknown agent: %s, event id: %s",
          event.author,
          event.id,
      )
      continue
    transferable = is_transferable_across_agent_tree(agent)
    if transferable:
      return _resolve_task_delegator(agent, root_agent)
  # Falls back to root agent if no suitable agents are found in the session.
  return root_agent


def restore_branch_from_history(
    invocation_context: InvocationContext,
    node: BaseNode,
    *,
    root: BaseNode,
    invocation_id: str | None = None,
) -> None:
  """Restores a non-root node's branch from its latest matching event.

  A freshly created ``InvocationContext`` has no branch, so a node that
  previously ran on a sub-branch (e.g. a resumed sub-agent, or an agent
  resolved by ``_find_agent_to_run``) would otherwise continue on the root
  branch.

  Tool branches are skipped. A tool's user-facing message is authored under
  the agent's name (``functions.py``) and stamped with the agent's node path
  (``base_agent.py``), so it is indistinguishable from the agent's own turns
  by author or path; what gives it away is its branch, which the same code
  builds as ``<tool>@<function_call_id>`` from a call in this session. Such a
  branch is therefore recognised and skipped, while every other event the node
  authored -- including a plain text turn, which is all a non-resumable
  sub-agent may leave behind -- still carries ``ctx.branch`` and is eligible.
  A branch whose leaf names the node itself is kept even when its id is a
  function call id, since that is how ``AgentTool`` scopes a real sub-agent.

  Nodes are matched by their static path (run ids stripped) so that two nodes
  sharing a name (e.g. the same sub-agent mounted under two parents) are
  disambiguated; events that predate node paths fall back to author/name
  matching. When ``invocation_id`` is provided (resuming a known invocation),
  only that invocation's events are considered, so a resumed node cannot
  inherit a stale branch authored in an earlier invocation. When it is None
  (a fresh direct-node turn, or a new invocation continuing a sub-agent), the
  most recent matching event across the session is used.
  """
  from ..events._rewind_events import _apply_rewinds
  from ..workflow._base_node import find_static_node_path

  live_events = _apply_rewinds(invocation_context.session.events)
  expected_static_path = find_static_node_path(root, node)
  tool_call_ids = _collect_function_call_ids(live_events)
  for event in reversed(live_events):
    if invocation_id is not None and event.invocation_id != invocation_id:
      continue
    if not event.branch:
      continue
    if _BranchPath.is_tool_branch(event.branch, node.name, tool_call_ids):
      continue
    matched = False
    if expected_static_path and event.node_info.path:
      event_static_path = _NodePathBuilder.from_string(
          event.node_info.path
      ).static_path
      if event_static_path == expected_static_path:
        matched = True
    elif event.author == node.name or event.node_info.name == node.name:
      matched = True
    if matched:
      invocation_context.branch = event.branch
      break
