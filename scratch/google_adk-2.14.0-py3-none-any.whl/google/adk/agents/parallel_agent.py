# Copyright 2026 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Parallel agent implementation."""

from __future__ import annotations

import asyncio
import logging
from typing import AsyncGenerator
from typing import ClassVar
import warnings

from typing_extensions import deprecated
from typing_extensions import override

from ..events._branch_path import _BranchPath
from ..events.event import Event
from ..utils.context_utils import Aclosing
from .base_agent import BaseAgent
from .base_agent import BaseAgentState
from .base_agent_config import BaseAgentConfig
from .invocation_context import InvocationContext

with warnings.catch_warnings():
  # ParallelAgentConfig subclasses the deprecated BaseAgentConfig purely as
  # an internal implementation detail, so this import alone should not warn
  # applications that never touch the deprecated Agent Config APIs.
  warnings.filterwarnings(
      'ignore',
      message=r'.*BaseAgentConfig is deprecated.*',
      category=DeprecationWarning,
  )
  from .parallel_agent_config import ParallelAgentConfig

logger = logging.getLogger('google_adk.' + __name__)


class _AgentRunComplete:
  """Queue marker emitted after one parallel agent finishes."""


def _create_branch_ctx_for_sub_agent(
    agent: BaseAgent,
    sub_agent: BaseAgent,
    invocation_context: InvocationContext,
) -> InvocationContext:
  """Create isolated branch for every sub-agent."""
  invocation_context = invocation_context.model_copy()
  branch_suffix = f'{agent.name}.{sub_agent.name}'
  invocation_context.branch = _BranchPath.create_sub_branch(
      invocation_context.branch, name=branch_suffix
  )
  return invocation_context


def _asks_this_agent_to_exit(event: Event, sub_agent_names: set[str]) -> bool:
  """Returns whether the event asks this parallel agent to exit early.

  An escalation ends the workflow that directly encloses the escalating agent,
  and that workflow re-yields the event while unwinding, so only an escalation
  authored by a direct sub-agent is addressed to this one.

  Args:
      event: The event to inspect.
      sub_agent_names: Names of this agent's direct sub-agents.

  Returns:
      Whether this parallel agent should stop its remaining branches.
  """
  return bool(event.actions.escalate) and event.author in sub_agent_names


def _cancel_tasks(tasks: list[asyncio.Task[None]]) -> None:
  """Cancels still-running merge tasks."""
  for task in tasks:
    if not task.done():
      task.cancel()


async def _merge_agent_run(
    agent_runs: list[AsyncGenerator[Event, None]],
    sub_agent_names: set[str] | None = None,
) -> AsyncGenerator[Event, None]:
  """Merges agent runs using asyncio.TaskGroup on Python 3.11+."""
  sub_agent_names = sub_agent_names or set()
  sentinel = _AgentRunComplete()
  queue: asyncio.Queue[
      tuple[Event | _AgentRunComplete, asyncio.Event | BaseException | None]
  ] = asyncio.Queue()
  tasks: list[asyncio.Task[None]] = []

  # Agents are processed in parallel.
  # Events for each agent are put on queue sequentially.
  async def process_an_agent(
      events_for_one_agent: AsyncGenerator[Event, None],
  ) -> None:
    error: BaseException | None = None
    try:
      async with Aclosing(events_for_one_agent):
        async for event in events_for_one_agent:
          resume_signal = asyncio.Event()
          await queue.put((event, resume_signal))
          # Wait for upstream to consume event before generating new events.
          await resume_signal.wait()
    except asyncio.CancelledError:
      logger.info('Agent run cancelled.')
      raise
    except Exception as e:
      # Reported through the queue rather than by failing the task: this
      # generator stays suspended at `yield` for as long as the caller is busy,
      # and a task group aborting around a suspended frame cancels the caller
      # instead of handing it the error.
      error = e
    finally:
      # Mark agent as finished, carrying the failure that ended it, if any.
      try:
        await queue.put((sentinel, error))
      except Exception as e:
        logger.warning('Failed to put sentinel on queue: %s', e)

  try:
    async with asyncio.TaskGroup() as tg:
      for events_for_one_agent in agent_runs:
        tasks.append(tg.create_task(process_an_agent(events_for_one_agent)))

      sentinel_count = 0
      # Run until all agents finished processing.
      while sentinel_count < len(agent_runs):
        event, payload = await queue.get()
        # Agent finished processing.
        if isinstance(event, _AgentRunComplete):
          sentinel_count += 1
          if isinstance(payload, BaseException):
            raise payload
        else:
          yield event
          if _asks_this_agent_to_exit(event, sub_agent_names):
            _cancel_tasks(tasks)
            return
          # Signal to agent that it should generate next event.
          if not isinstance(payload, asyncio.Event):
            raise RuntimeError(
                'Parallel-agent event is missing its resume signal.'
            )
          payload.set()
  except BaseExceptionGroup as eg:
    # A branch failure travels back on the queue and is re-raised above, so the
    # group wraps that one error. Hand the caller the error itself, so that
    # catching what a sub-agent raises works the same on every supported
    # interpreter. A group holding more than one error is not ours to reshape.
    if len(eg.exceptions) == 1:
      raise eg.exceptions[0] from None
    raise


# Backward-compatibility alias for callers referencing the pre-3.11 helper.
_merge_agent_run_pre_3_11 = _merge_agent_run


@deprecated(
    'ParallelAgent is deprecated in favor of Workflow and will be removed in'
    ' a future version. Workflow cannot yet be used as an LlmAgent sub-agent.'
)
class ParallelAgent(BaseAgent):
  """A shell agent that runs its sub-agents in parallel on separate branches.

  This approach is beneficial for scenarios requiring multiple perspectives or
  attempts on a single task, such as:

  - Running different algorithms simultaneously.
  - Generating multiple responses for review by a subsequent evaluation agent.

  Only conversation history is isolated between branches: a sub-agent sees the
  events that led to the fan-out and its own, but not those of a sibling.
  Session state is shared by every branch, so branches writing the same key
  leave only the value written last.

  .. deprecated::
    ParallelAgent is deprecated in favor of Workflow and will be removed in a
    future version. Workflow cannot yet be used as an LlmAgent sub-agent.
  """

  config_type: ClassVar[type[BaseAgentConfig]] = ParallelAgentConfig
  """The config type for this agent.

  DEPRECATED: This attribute is deprecated and will be removed in a future
  version, along with the AgentConfig YAML loader.
  """

  @override
  async def _run_async_impl(
      self, ctx: InvocationContext
  ) -> AsyncGenerator[Event, None]:
    if not self.sub_agents:
      return

    agent_state = self._load_agent_state(ctx, BaseAgentState)
    if ctx.is_resumable and agent_state is None:
      ctx.set_agent_state(self.name, agent_state=BaseAgentState())
      yield self._create_agent_state_event(ctx)

    agent_runs = []
    sub_agent_names = {sub_agent.name for sub_agent in self.sub_agents}
    # Prepare and collect async generators for each sub-agent.
    for sub_agent in self.sub_agents:
      sub_agent_ctx = _create_branch_ctx_for_sub_agent(self, sub_agent, ctx)

      # Only include sub-agents that haven't finished in a previous run.
      if not sub_agent_ctx.end_of_agents.get(sub_agent.name):
        agent_runs.append(sub_agent.run_async(sub_agent_ctx))

    escalated = False
    pause_invocation = False
    async with Aclosing(_merge_agent_run(agent_runs, sub_agent_names)) as agen:
      async for event in agen:
        yield event
        if _asks_this_agent_to_exit(event, sub_agent_names):
          escalated = True
        if ctx.should_pause_invocation(event):
          pause_invocation = True

    if pause_invocation:
      return

    # Once all sub-agents are done, mark the ParallelAgent as final.
    if ctx.is_resumable and (
        escalated
        or all(
            ctx.end_of_agents.get(sub_agent.name)
            for sub_agent in self.sub_agents
        )
    ):
      ctx.set_agent_state(self.name, end_of_agent=True)
      yield self._create_agent_state_event(ctx)

  @override
  async def _run_live_impl(
      self, ctx: InvocationContext
  ) -> AsyncGenerator[Event, None]:
    raise NotImplementedError('This is not supported yet for ParallelAgent.')
    yield  # AsyncGenerator requires having at least one yield statement
